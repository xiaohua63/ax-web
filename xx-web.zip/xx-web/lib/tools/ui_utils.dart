import 'package:flutter/material.dart';
import 'package:xx_study/components/round_app_bar.dart';

const Duration _snackBarDisplayDuration = Duration(milliseconds: 4000);

void showSnackBar(ctx, String msg,
    {String? actionText,
    VoidCallback? action,
    Duration duration = _snackBarDisplayDuration}) {
  SnackBar snackBar = SnackBar(
    content: Text(msg),
    action: actionText == null
        ? null
        : SnackBarAction(label: actionText, onPressed: action!),
    duration: duration,
  );
  ScaffoldMessenger.of(ctx).hideCurrentSnackBar();
  ScaffoldMessenger.of(ctx).showSnackBar(snackBar);
}

Widget wrapColor(child, Color color,
    {AlignmentGeometry alignment = Alignment.center}) {
  return Container(
    width: double.maxFinite,
    alignment: alignment,
    height: double.maxFinite,
    decoration: BoxDecoration(color: color),
    child: child,
  );
}

Widget wrapHeader(child, double width, Color color,
    {AlignmentGeometry alignment = Alignment.center}) {
  return Container(
    width: width,
    alignment: alignment,
    height: double.maxFinite,
    decoration: BoxDecoration(color: color),
    child: child,
  );
}

void showCommonList(ctx, String title, List children) {
  showModalBottomSheet(
    context: ctx,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (ctx) => Scaffold(
      backgroundColor: Colors.transparent,
      appBar: RoundAppBar(
        title: Text(title),
        leading: const CloseButton(),
      ),
      body: SelectionArea(
        child: ListView(
          children: List.from(children),
        ),
      ),
    ),
  );
}

void showDialogList(ctx, String title, List<Widget> children,
    {List<Widget>? actions}) {
  showDialog(
    context: ctx,
    useSafeArea: true,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: SizedBox(
        height: 360,
        width: 320,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: children.length,
          itemBuilder: (c, i) => children[i],
        ),
      ),
      actions: actions,
    ),
  );
}

class WrapVar<T> {
  T _v;

  WrapVar(this._v);

  void set(T c) {
    _v = c;
  }

  T get() => _v;
}

Widget buildRadio(ctx, WrapVar<int> value, String title, List<String> options) {
  var ws = <Widget>[];

  var v = 0;
  for (var t in options) {
    var c = v++;
    ws.add(Radio(
      value: c,
      onChanged: (b) {
        value.set(c);
        (ctx as Element).markNeedsBuild();
      },
      groupValue: value.get(),
    ));
    ws.add(Text(t));
  }

  return Row(
    mainAxisSize: MainAxisSize.min,
    children: [Text(title), ...ws],
  );
}
