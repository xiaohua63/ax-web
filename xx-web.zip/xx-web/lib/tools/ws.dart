import 'dart:convert';

import 'package:web_socket_channel/web_socket_channel.dart';

import '../tools/config.dart';
import '../tools/http.dart';
import '../tools/logger.dart';

abstract class EventListener {
  void onAccountLoginSuccess(dynamic data);

  void onTokenInvalid();

  void onConnectStatusChanged();
}

class AppSocket {
  static WebSocketChannel? _webSocket;

  static bool running = false;
  static bool connected = false;
  static EventListener? eventListener;
  static void Function(String?)? logListener;
  static void Function(dynamic)? loginListener;

  static void start(EventListener listener) async {
    eventListener = listener;
    if (running) return;
    logging.d("ws start");
    running = true;
    eventListener?.onConnectStatusChanged();
    await _loop_connect();
  }

  static void parseMsg(String msg) {
    Map<String, dynamic> d;
    try {
      d = jsonDecode(msg);
    } catch (e) {
      return;
    }
    if (d.containsKey("type")) {
      int t = d['type'];
      switch (t) {
        case 13:
          logListener?.call(d["data"]);
          break;
        case 14:
          if (d["data"] is String) {
            eventListener?.onAccountLoginSuccess(
                {"name": d["data"], "success": true, "reason": ""});
          } else {
            eventListener?.onAccountLoginSuccess(d["data"]);
          }
          break;
        case 12:
          break;
      }
    }
  }

  static Future<void> _loop_connect() async {
    if (!running) return;

    //Android和iOS端使用的是：IOWebSocketChannel.connect(connectUrl);
    //Web 端使用的是：HtmlWebSocketChannel.connect(connectUrl);
    if (_webSocket != null) return;
    _webSocket = WebSocketChannel.connect(Uri.parse(
        'ws://${HttpTool.baseUrlNoHttp}/web_dc/${await AppConfig.token()}'));
    _webSocket?.stream.listen((event) {
      connected = true;
      eventListener?.onConnectStatusChanged();
      logging.d("onData[${identityHashCode(_webSocket)}]: $event");
      parseMsg(event.toString());
    }, onError: (e) {
      connected = false;
      logging.d("ws onError[${identityHashCode(_webSocket)}]. $e");
      _webSocket?.sink.close();
      _webSocket = null;
      if (running) {
        Future.delayed(const Duration(seconds: 5), _loop_connect);
      }
      eventListener?.onConnectStatusChanged();
    }, onDone: () {
      logging.d(
          "onDone[${identityHashCode(_webSocket)}]. ${_webSocket?.closeCode}");
      var closeCode = _webSocket?.closeCode;
      _webSocket = null;
      if (closeCode == 4001) {
        eventListener?.onTokenInvalid();
        stop();
      } else {
        connected = false;
        eventListener?.onConnectStatusChanged();
      }
      if (running) {
        Future.delayed(const Duration(seconds: 5), _loop_connect);
      }
    }, cancelOnError: true);
  }

  static void stop() {
    running = false;
    connected = false;
    // eventListener = null;
    logging.d("ws stop.");
    if (_webSocket != null) {
      logging.d("ws close.");
      _webSocket?.sink.close(1000, "exited");
      _webSocket = null;
    }
    eventListener?.onConnectStatusChanged();
  }

  static void _sendCmd(type, data) {
    var d = jsonEncode({"type": type, "data": data});
    // logging.d("_sendCmd: $d");
    _webSocket?.sink.add(d);
  }

  static void sendListenLog(bool b, deviceId, listener) {
    logListener = listener;
    _sendCmd(13, {"device_id": deviceId, "enabled": b});
  }

  static void upgradeApp(String? deviceId) {
    _sendCmd(22, deviceId);
  }
}
