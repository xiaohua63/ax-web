import 'package:shared_preferences/shared_preferences.dart';

class AppConfig {
  static AppConfig? _appConfig;

  static AppConfig getInstance() {
    _appConfig ??= AppConfig();
    return _appConfig!;
  }

  static Future<bool> isLogin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey("token");
  }

  static setHostUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString("host_url", url);
  }

  static Future<String?> hostUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("host_url");
  }

  static void logout() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove("token");
  }

  static void saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString("token", token);
  }

  static Future<String> token() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("token")!;
  }
}
