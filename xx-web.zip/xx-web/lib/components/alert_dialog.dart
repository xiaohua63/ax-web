import 'package:flutter/material.dart';

typedef BoolCallback = bool Function();

void showAlert(
  context, {
  required String title,
  required onConfirm,
  String? content,
  bool barrierDismissible = true,
  bool showCancel = true,
}) {
  showDialog(
    context: context,
    barrierDismissible: barrierDismissible,
    builder: (ctx) {
      return AlertDialog(
        title: Text(title),
        content: content == null ? null : SelectableText(content),
        actions: [
          if (showCancel)
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("取消"),
            ),
          TextButton(
            onPressed: () async {
              var f = onConfirm();
              if ((f is Future && await f) || f) {
                Navigator.pop(ctx);
              }
            },
            child: const Text("确定"),
          ),
        ],
      );
    },
  );
}
