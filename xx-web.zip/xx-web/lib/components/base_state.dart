import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../tools/utils.dart';

abstract class BaseState<T extends StatefulWidget> extends State<T>
    with AutomaticKeepAliveClientMixin {
  static const int statusLoading = 0;
  static const int statusSuccess = 1;
  static const int statusError = 2;
  static const int statusNoLogin = 3;

  @override
  bool get wantKeepAlive => false;

  int currentStatus = statusLoading;
  dynamic successData;
  dynamic errorData;

  Function? errAction;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    // return buildScaffold(IndexedStack(
    //   index: currentStatus,
    //   children: [
    //     buildLoadingView(),
    //     buildSuccessView(successData),
    //     buildNeedLoginView(),
    //     buildErrorView(),
    //   ],
    // ));

    if (currentStatus == BaseState.statusLoading) {
      return buildScaffold(buildLoadingView());
    } else if (currentStatus == BaseState.statusSuccess) {
      return buildScaffold(buildSuccessView(successData));
    } else if (currentStatus == BaseState.statusNoLogin) {
      return buildScaffold(buildNeedLoginView());
    } else {
      return buildScaffold(buildErrorView());
    }
  }

  Future<void> onLoad();

  void reload({bool showLoading = true}) {
    if(showLoading) {
      notifyLoading();
    }
    onLoad().then((value) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void initState() {
    super.initState();
    reload();
    fabVisibility = true;
    scrollCtrl.addListener(() {
      if (!scrollCtrl.hasClients) return;
      bool vis =
          scrollCtrl.position.userScrollDirection == ScrollDirection.forward;
      if (vis != fabVisibility) {
        setState(() {
          fabVisibility = vis;
        });
      }
    });
  }

  Widget fabAnimateWrap(child) {
    return fabAnimateWrap2(fabVisibility, child);
  }

  var scrollCtrl = ScrollController();
  bool fabVisibility = true;

  void notifySuccess(dynamic data) {
    if (!mounted) return;
    setState(() {
      successData = data;
      currentStatus = statusSuccess;
    });
  }

  void notifyLoading() {
    currentStatus = statusLoading;
    if (mounted) {
      setState(() {});
    }
  }

  void notifyError(data, {Function? action}) {
    setState(() {
      errAction = action;
      successData = null;
      errorData = data;
      currentStatus = statusError;
    });
  }

  void notifyNoLogin() {
    setState(() {
      successData = null;
      errorData = null;
      currentStatus = statusNoLogin;
    });
  }

  Widget buildLoadingView() {
    return const Center(child: CircularProgressIndicator());
  }

  Widget buildSuccessView(data);

  Widget buildScaffold(Widget child) {
    return child;
  }

  Widget buildErrorView() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("$errorData"),
          TextButton(
              onPressed: () {
                errAction?.call();
                errAction = null;
                notifyLoading();
                onLoad().then((value) {
                  setState(() {});
                });
              },
              child: const Text("刷新"))
        ],
      ),
    );
  }

  Widget buildNeedLoginView() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text("登录过期"),
          TextButton(
              onPressed: () {
                Navigator.popAndPushNamed(context, "/login");
              },
              child: const Text("重新登录"))
        ],
      ),
    );
  }
}
