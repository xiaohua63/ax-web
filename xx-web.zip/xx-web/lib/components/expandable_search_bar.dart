// ignore_for_file: must_be_immutable
library animated_search_bar;

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class ExpandableSearchBar extends StatefulWidget {
  final ValueChanged<String>? onSubmitted;
  final ValueChanged<String>? onChanged;

  ExpandableSearchBar({
    Key? key,
    required this.hintText,
    required this.editTextController,
    this.width = 200,
    this.iconSize = 45,
    this.textSize = 15,
    this.gutter = 20,
    this.radius,
    this.animationDuration = const Duration(milliseconds: 500),
    this.animationCurve = Curves.fastOutSlowIn,
    this.textFieldAnimationDuration = const Duration(milliseconds: 200),
    this.textFieldAnimationCurve = Curves.easeInOut,
    this.iconBoxShadow,
    this.iconColor = const Color(0xff47E10C),
    this.iconBackgroundColor = const Color(0xff353535),
    this.onSubmitted,
    this.onChanged,
    this.backgroundColor = const Color(0xff101010),
  }) : super(key: key);

  /// Animated bar width.
  final double width;

  /// Suffix icon width.
  ///
  /// Note: this icon is a sizedBox widget.
  final double iconSize;
  final double textSize;
  final double? radius;

  /// Some extra space for expanded bar.
  final double? gutter;

  /// Hint text for textField inside expandable bar.
  final String? hintText;

  /// Animation duration for expandable bar.
  ///
  /// default is 500 milliseconds
  final Duration animationDuration;

  /// Animation curve for expandable bar.
  ///
  /// Default is Curves.fastOutSlowIn
  ///
  /// Note: Other curves may be glitchy.
  final Cubic animationCurve;

  /// Animation duration for textField.
  ///
  /// Default is 200 milliseconds
  final Duration textFieldAnimationDuration;

  /// Animation curve for textField.
  ///
  /// Default is Curves.easeInOut
  final Cubic textFieldAnimationCurve;

  /// Controller for textfield
  TextEditingController? editTextController;

  /// Shadow for icon button.
  final List<BoxShadow>? iconBoxShadow;

  /// Button Icon color.
  /// If not set default will be:
  /// ```dart
  /// const Color(0xff47E10C)
  /// ```
  final Color iconColor;

  /// Button Icon color.
  /// If not set default will be:
  /// ```dart
  ///const Color(0xff353535)
  /// ```
  final Color iconBackgroundColor;

  /// Background color for animated bar.
  /// If not set default will be:
  /// ```dart
  /// const Color(0xff101010)
  /// ```
  final Color backgroundColor;

  @override
  State<ExpandableSearchBar> createState() => _ExpandableSearchBarState();
}

class _ExpandableSearchBarState extends State<ExpandableSearchBar> {
  bool isSearchbarHidden = true;
  FocusNode inputFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    var c = widget.editTextController;
    if (c != null) {
      isSearchbarHidden = c.text.isEmpty;
    }
  }

  @override
  Widget build(BuildContext context) {
    var radius = widget.radius ?? widget.iconSize / 2;
    return MouseRegion(
      onEnter: (details) => setState(() {
        isSearchbarHidden = false;
        FocusScope.of(context).requestFocus(inputFocus);
      }),
      onExit: (details) => setState(() {
        // amIHovering = false;
        if ((widget.editTextController?.text.trim() ?? "").isEmpty) {
          isSearchbarHidden = true;
          inputFocus.unfocus();
        }
        // You can use details.position if you are interested in the global position of your pointer.
        // exitFrom = details.localPosition;
      }),
      child:
      AnimatedContainer(
        width: isSearchbarHidden
            ? widget.iconSize
            : widget.width + (widget.gutter as double),
        duration: widget.animationDuration,
        curve: widget.animationCurve,
        padding: isSearchbarHidden
            ? const EdgeInsets.all(0)
            : EdgeInsets.only(left: radius),
        decoration: BoxDecoration(
          color: widget.backgroundColor,
          borderRadius: BorderRadius.all(Radius.circular(radius)),
          boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).shadowColor.withAlpha(80),
                    blurRadius: 6,
                    offset: const Offset(0, 4),
                  ),
                ],
        ),
        child: Stack(
          children: [
            AnimatedContainer(
              padding: (!kIsWeb && (Platform.isAndroid || Platform.isIOS))
                  ? null
                  : const EdgeInsets.only(bottom: 8),
              width: isSearchbarHidden
                  ? widget.iconSize
                  : widget.width - (widget.iconSize),
              height: widget.iconSize,
              duration: widget.textFieldAnimationDuration,
              curve: widget.textFieldAnimationCurve,
              child: SizedBox(
                height: widget.iconSize,
                child: Center(
                  child: TextField(
                    controller: widget.editTextController,
                    decoration: InputDecoration(
                      hintText: widget.hintText,
                      border: InputBorder.none,
                    ),
                    style: TextStyle(fontSize: widget.textSize),
                    textInputAction: TextInputAction.search,
                    onSubmitted: widget.onSubmitted,
                    onChanged: widget.onChanged,
                    focusNode: inputFocus,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                height: widget.iconSize,
                width: widget.iconSize,
                child: FloatingActionButton.small(
                  elevation: 0,
                  shape: const CircleBorder(),
                  onPressed: () {
                    setState(() {
                      isSearchbarHidden = !isSearchbarHidden;
                      if (isSearchbarHidden) {
                        inputFocus.unfocus();
                      } else {
                        FocusScope.of(context).requestFocus(inputFocus);
                      }
                    });
                  },
                  child: const Icon(Icons.search),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
