import 'package:flutter/material.dart';

List<NavigationDestination> l2Destinations = [
  const NavigationDestination(
    tooltip: "",
    icon: Icon(Icons.home),
    label: '首页',
    selectedIcon: Icon(Icons.home),
  ),
  const NavigationDestination(
    tooltip: "",
    icon: Icon(Icons.group),
    label: '账号管理',
    selectedIcon: Icon(Icons.group),
  ),
];

List<NavigationDestination> l1Destinations = l2Destinations +
    [
      const NavigationDestination(
        tooltip: "",
        icon: Icon(Icons.support_agent),
        label: '我的代理',
        selectedIcon: Icon(Icons.support_agent_sharp),
      ),
    ];

List<NavigationDestination> adminDestinations = l1Destinations +
    [
      const NavigationDestination(
        tooltip: "",
        icon: Icon(Icons.security),
        label: '管理员',
        selectedIcon: Icon(Icons.security),
      ),
      const NavigationDestination(
        tooltip: "",
        icon: Icon(Icons.phone_android),
        label: '设备管理',
        selectedIcon: Icon(Icons.phone_android),
      ),
    ];

class NavigationRailSection extends StatefulWidget {
  final void Function(int) onSelectItem;
  final int selectedIndex;
  final List<NavigationDestination> appBarDestinations;
  final List<NavigationRailDestination> navRailDestinations = [];

  NavigationRailSection(
      {super.key,
      required this.onSelectItem,
      required this.selectedIndex,
      required this.appBarDestinations}) {
    navRailDestinations.addAll(appBarDestinations.map(
      (destination) => NavigationRailDestination(
          icon: Tooltip(
            message: destination.label,
            child: destination.icon,
          ),
          selectedIcon: Tooltip(
            message: destination.label,
            child: destination.selectedIcon,
          ),
          label: Text(destination.label),
          padding: const EdgeInsets.symmetric(vertical: 5)),
    ));
  }

  @override
  State<NavigationRailSection> createState() => _NavigationRailSectionState();
}

class _NavigationRailSectionState extends State<NavigationRailSection> {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.selectedIndex;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: SizedBox(
          width: 50,
          height: widget.navRailDestinations.length * 60,
          child: NavigationRail(
            minWidth: 50,
            destinations: widget.navRailDestinations,
            selectedIndex: _selectedIndex,
            useIndicator: true,
            onDestinationSelected: (index) {
              setState(() {
                _selectedIndex = index;
              });
              widget.onSelectItem(index);
            },
          )),
    );
  }
}

class NavigationBars extends StatefulWidget {
  final void Function(int)? onSelectItem;
  final int selectedIndex;
  final List<NavigationDestination> appBarDestinations;

  const NavigationBars({
    super.key,
    this.onSelectItem,
    required this.selectedIndex,
    required this.appBarDestinations,
  });

  @override
  State<NavigationBars> createState() => _NavigationBarsState();
}

class _NavigationBarsState extends State<NavigationBars> {
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    selectedIndex = widget.selectedIndex;
  }

  @override
  Widget build(BuildContext context) {
    return NavigationBar(
      selectedIndex: selectedIndex,
      onDestinationSelected: (index) {
        setState(() {
          selectedIndex = index;
        });
        widget.onSelectItem!(index);
      },
      destinations: widget.appBarDestinations,
    );
  }
}
