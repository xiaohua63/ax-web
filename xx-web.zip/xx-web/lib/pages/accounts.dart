import 'dart:convert';
import 'dart:math';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:xx_study/components/input_dialog.dart';
import 'package:xx_study/components/loading_dialog.dart';

import '../components/base_state.dart';
import '../components/expandable_search_bar.dart';
import '../components/sticky_table/custom_properties/cell_dimensions.dart';
import '../components/sticky_table/sticky_headers_table.dart';
import '../tools/http.dart';
import '../tools/logger.dart';
import '../tools/ui_utils.dart';
import '../tools/utils.dart';

class AccountsPage extends StatefulWidget {
  final Function? refreshUser;
  final int screenMode;
  final bool isAdmin;
  final int userStudyType;
  final List? accList;
  final String sortBy;
  final bool sortByDesc;

  bool get viewMode => accList != null;

  const AccountsPage(
      this.isAdmin, this.userStudyType, this.screenMode, this.refreshUser,
      {super.key})
      : accList = null,
        sortBy = "",
        sortByDesc = false;

  const AccountsPage.withData(this.accList, this.isAdmin, this.userStudyType,
      {super.key})
      : refreshUser = null,
        screenMode = 1,
        sortBy = "积分更新",
        sortByDesc = true;

  @override
  State createState() => _AccountState(sortBy, sortByDesc);
}

class _AccountState extends BaseState<AccountsPage> {
  @override
  bool get wantKeepAlive => true;

  String searchText = "";
  var getAll = false;
  String? filterType;
  String filterName = "全部";

  var filterMap = {
    "全部": null,
    "已学习": "only_studied",
    "未学习": "only_not_studied",
    "未登录": "only_not_login",
    "已登录": "only_login",
    "已过期": "only_out_date",
    "未过期": "only_not_out_date",
  };

  List<String> _filterKeys = [];

  List<String> getFilterKeys() {
    if (_filterKeys.isEmpty) {
      _filterKeys.addAll(filterMap.keys.toList());
    }
    return _filterKeys;
  }

  var tableX = 0.0;
  var tableY = 0.0;
  var page = 1;
  var pageSize = 20;
  var maxPage = 0;
  var totalCount = 0;
  var sortBy = "";
  var sortByDesc = false;
  List<String> checkedAcs = [];
  List<AccountItemHolder> accounts = [];

  _AccountState(this.sortBy, this.sortByDesc);

  @override
  Future<void> onLoad() async {
    if (!widget.viewMode) {
      await refreshList();
    } else {
      notifySuccess(
          {"max_page": maxPage, "total": totalCount, "list": widget.accList});
    }
  }

  Future<void> refreshList([bool ru = false]) {
    setState(() {
      checkedAcs.clear();
    });
    if (ru) widget.refreshUser?.call();
    var st = searchText.isEmpty ? "" : "%$searchText%";
    return Future.sync(() async {
      dynamic resp;
      try {
        resp = await Http.getJson("/user/account/list2", queries: {
          "page": page.toString(),
          "size": pageSize.toString(),
          "search_text": st,
          if (filterType != null) "filter_type": filterType!,
          "search_all": getAll ? "1" : "0",
          "sort_by": (sortBy.isNotEmpty ? sortNames[sortBy] ?? "" : "") +
              (sortByDesc ? "#" : ""),
        });
      } catch (e) {
        setState(() {
          notifyError("网络错误");
        });
        return;
      }
      if (resp["code"] == 0) {
        if (resp['data'].isEmpty) {
          notifyError("无数据");
        } else {
          notifySuccess(resp['data']);
        }
      } else if (resp['code'] != -9) {
        notifyError(resp["message"]);
      } else {
        notifyNoLogin();
      }
    });
  }

  @override
  Widget buildLoadingView() {
    return buildSuccessView(
        {"max_page": maxPage, "total": totalCount, "list": []});
  }

  @override
  Widget buildScaffold(Widget child) {
    var pageCtrl = TextEditingController(text: page.toString());
    var searchCtrl = TextEditingController(text: searchText);
    return Scaffold(
      body: Column(
        children: [
          Expanded(child: child),
          if (currentStatus == BaseState.statusLoading)
            Expanded(child: super.buildLoadingView()),
          if (!widget.viewMode)
            Align(
              alignment: Alignment.centerRight,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.only(
                    left: 20, top: 8, bottom: 8, right: 30),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Offstage(
                      offstage: checkedAcs.isEmpty,
                      child: FloatingActionButton.small(
                        backgroundColor:
                            Theme.of(context).colorScheme.background,
                        shape: const CircleBorder(),
                        onPressed: batchRenewal,
                        tooltip: "续费",
                        child: const Icon(
                          Icons.add_box,
                          color: Colors.lightGreenAccent,
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Offstage(
                      offstage: checkedAcs.isEmpty,
                      child: FloatingActionButton.small(
                        backgroundColor:
                            Theme.of(context).colorScheme.background,
                        shape: const CircleBorder(),
                        onPressed: batchDelete,
                        tooltip: "删除",
                        child: const Icon(
                          Icons.delete_outline,
                          color: Colors.redAccent,
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    ExpandableSearchBar(
                      iconSize: 38,
                      textSize: 13,
                      backgroundColor: Theme.of(context).colorScheme.background,
                      animationDuration: const Duration(milliseconds: 300),
                      onChanged: (s) => searchText = s.trim(),
                      onSubmitted: (s) {
                        if (s.isNotEmpty) {
                          page = 1;
                          searchText = s.trim();
                          reload();
                        } else if (searchText.isNotEmpty) {
                          searchText = "";
                          page = 1;
                          reload();
                        }
                      },
                      hintText: "账号搜索",
                      editTextController: searchCtrl,
                    ),
                    const SizedBox(width: 20),
                    FloatingActionButton.small(
                      backgroundColor: Theme.of(context).colorScheme.background,
                      shape: const CircleBorder(),
                      onPressed: exportOption,
                      tooltip: "导出表格",
                      child: const Icon(Icons.table_rows_outlined),
                    ),
                    const SizedBox(width: 20),
                    FloatingActionButton.small(
                      backgroundColor: Theme.of(context).colorScheme.background,
                      shape: const CircleBorder(),
                      onPressed: addAccount,
                      tooltip: "添加账号(长按批量)",
                      child: GestureDetector(
                        onLongPress: batchAddAccount,
                        child: const Icon(Icons.add),
                      ),
                    ),
                    const SizedBox(width: 20),
                    FloatingActionButton.small(
                      backgroundColor: Theme.of(context).colorScheme.background,
                      shape: const CircleBorder(),
                      onPressed: reload,
                      tooltip: "刷新",
                      child: const Icon(Icons.sync),
                    ),
                    const SizedBox(width: 20),
                    Text(
                      "${(page - 1) * pageSize + 1}-${min(totalCount, (page) * pageSize)} / $totalCount",
                      style: const TextStyle(fontFamily: "FiraMono"),
                    ),
                    IconButton(
                      tooltip: "上页",
                      onPressed: page == 1 ? null : loadPrePage,
                      icon: const Icon(Icons.keyboard_arrow_left),
                    ),
                    const SizedBox(width: 10),
                    SizedBox(
                      width: 20,
                      child: TextField(
                        maxLength: maxPage.toString().length,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 15,
                            color: Colors.blueAccent,
                            fontFamily: "FiraMono",
                            fontWeight: FontWeight.bold),
                        cursorHeight: 13,
                        controller: pageCtrl,
                        decoration: const InputDecoration(
                            border: InputBorder.none, counterText: ""),
                        textInputAction: TextInputAction.go,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        onSubmitted: (s) {
                          if (s.isNotEmpty) {
                            int goPage = int.parse(s.trim());
                            if (goPage > 0 && goPage <= maxPage) {
                              page = goPage;
                              reload();
                            } else {
                              pageCtrl.text = page.toString();
                            }
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton(
                      tooltip: "下页",
                      onPressed: page < maxPage ? loadNextPage : null,
                      icon: const Icon(Icons.keyboard_arrow_right),
                    ),
                    const SizedBox(width: 10),
                    DropdownButton(
                      focusColor: Colors.transparent,
                      underline: const SizedBox(),
                      style: TextStyle(
                        fontWeight: FontWeight.normal,
                        color: Theme.of(context).textTheme.bodySmall!.color,
                      ),
                      value: pageSize.toString(),
                      items: ["10", "20", "50"]
                          .map(
                              (e) => DropdownMenuItem(value: e, child: Text(e)))
                          .toList(),
                      onChanged: (v) {
                        setState(() {
                          var newPageSize = int.parse(v ?? "20");
                          if (newPageSize != pageSize) {
                            pageSize = newPageSize;
                            page = 1;
                            reload();
                          }
                        });
                      },
                    ),
                    const SizedBox(width: 10),
                    DropdownButton(
                      focusColor: Colors.transparent,
                      underline: const SizedBox(),
                      value: filterName,
                      items: filterMap.keys
                          .map((e) => DropdownMenuItem(
                              value: e,
                              child: Text(e,
                                  style: const TextStyle(fontSize: 14))))
                          .toList(),
                      onChanged: (e) {
                        setState(() {
                          filterType = filterMap[e];
                          filterName = e!;
                          reload();
                        });
                      },
                    ),
                    const SizedBox(width: 20),
                    if (widget.isAdmin)
                      Checkbox(
                        value: getAll,
                        onChanged: (_) {
                          setState(() {
                            getAll = !getAll;
                            reload();
                          });
                        },
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  var headerTips = {"异常次数": "仅显示30天内的记录"};

  var headers = {
    "今日/总积分": 140.0,
    "积分更新": 110.0,
    "过期日期": 120.0,
    "添加日期": 140.0,
    "状态": 90.0,
    "异常次数": 90.0,
    "绑定设备": 110.0,
    "ID": 80.0,
    "代理": 60.0,
    "备注": 190.0,
    "操作": 160.0,
  };

  var sortNames = {
    "今日/总积分": "today_score",
    // "总积分": "total_score",
    "积分更新": "score_update_date",
    "账号": "name",
    "状态": "status_color",
    "添加日期": "add_time",
    "过期日期": "validity_date",
    "绑定设备": "device",
    "ID": "id",
  };

  Widget sortedHeaderWidget(String header, child) {
    if (sortNames.containsKey(header)) {
      const iconSize = 18.0;
      return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            const SizedBox(width: iconSize),
            child,
            Opacity(
              opacity: sortBy == header ? 1.0 : 0.0,
              child: Icon(
                  size: iconSize,
                  sortByDesc ? Icons.arrow_drop_down : Icons.arrow_drop_up),
            ),
          ]);
    }
    return child;
  }

  void changeSortBy(String header) {
    if (currentStatus == BaseState.statusLoading) {
      return;
    }
    setState(() {
      if (sortBy == header) {
        if (!sortByDesc) {
          sortByDesc = true;
        } else {
          sortByDesc = false;
          sortBy = "";
        }
      } else {
        sortByDesc = false;
        sortBy = header;
      }
      logging.d("changeSortBy $header $sortBy $sortByDesc");
      if (!widget.viewMode) {
        reload();
      }
    });
  }

  String headerAt(int index) {
    return headers.entries.toList()[index].key;
  }

  void sortLocal(List<AccountItemHolder> accounts) {
    if (sortBy.isEmpty) return;
    logging.d("sortLocal $sortBy desc:$sortByDesc");
    accounts.sort((a, b) {
      if (sortByDesc) {
        var c = b;
        b = a;
        a = c;
      }
      switch (sortNames[sortBy]) {
        case "today_score":
          return a.todayScore.compareTo(b.todayScore);
        case "score_update_date":
          return a.scoreDate.compareTo(b.scoreDate);
        case "name":
          return a.accountName.compareTo(b.accountName);
        case "status_color":
          return a.statusColor.compareTo(b.statusColor);
        case "add_time":
          return a.addTime.compareTo(b.addTime);
        case "validity_date":
          return a.validityDate.compareTo(b.validityDate);
        case "id":
          return a.accountId.compareTo(b.accountId);
        case "device":
          return a.accountId.compareTo(b.accountId);
      }
      return 0;
    });
  }

  @override
  Widget buildSuccessView(data) {
    logging.d(jsonEncode(data));
    if (widget.isAdmin && getAll) {
      var c = headers["操作"]!;
      headers.remove("操作");
      headers["代理"] = 60;
      headers["操作"] = c;
    } else {
      headers.remove("代理");
    }

    maxPage = data["max_page"];
    totalCount = data["total"];
    accounts = List.from(
      data["list"].map((e) => AccountItemHolder(e, refreshList)).toList(),
    );

    if (widget.viewMode) {
      // headers.remove("操作");
      sortLocal(accounts);
      // headers["密码"] = 80.0;
    }
    var stickyLegendWidth = 150.0;
    List<double> columnWidths = headers.values.toList();
    var w = columnWidths.fold(0.0, (t, i) => t + i);
    var navBarW = (widget.screenMode == 0 ? 62 : 0);
    var screenW = MediaQuery.of(context).size.width - navBarW;
    var W = max(w, screenW) - stickyLegendWidth;
    for (int i = 0; i < columnWidths.length; i++) {
      columnWidths[i] = columnWidths[i] / w * W;
    }

    return StickyHeadersTable(
      onColumnTitlePressed: (int c) {
        var header = headerAt(c);
        if (sortNames.containsKey(header)) {
          changeSortBy(header);
        }
        logging.d("onColumnTitlePressed $c");
      },
      onStickyLegendPressed: () {
        changeSortBy("账号");
      },
      onEndScrolling: (x, y) {
        tableX = x;
        tableY = y;
      },
      showHorizontalScrollbar: true,
      showVerticalScrollbar: true,
      legendCell: wrapHeader(
          sortedHeaderWidget(
              "账号",
              Row(
                children: [
                  Offstage(
                    offstage: widget.viewMode,
                    child: Checkbox(
                        value: accounts.isNotEmpty &&
                            checkedAcs.length == accounts.length,
                        onChanged: (c) {
                          allCheck(accounts);
                        }),
                  ),
                  const Text("账号")
                ],
              )),
          stickyLegendWidth,
          const Color(0xfff2f2f2),
          alignment: Alignment.centerLeft),
      columnsLength: headers.length,
      rowsLength: accounts.length,
      cellDimensions: CellDimensions.variableColumnWidth(
          columnWidths: columnWidths,
          contentCellHeight: 50,
          stickyLegendWidth: stickyLegendWidth,
          stickyLegendHeight: 50),
      columnsTitleBuilder: (int columnIndex) {
        var header = headerAt(columnIndex);
        var tv = Text(header);
        return wrapHeader(
          sortedHeaderWidget(
              header,
              headerTips.containsKey(header)
                  ? Tooltip(message: headerTips[header], child: tv)
                  : tv),
          columnWidths[columnIndex],
          const Color(0xfff0f0f0),
        );
      },
      rowsTitleBuilder: (int rowIndex) => wrapColor(
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Offstage(
                    offstage: widget.viewMode,
                    child: Checkbox(
                        value:
                            checkedAcs.contains(accounts[rowIndex].accountName),
                        onChanged: (c) {
                          var accountItem = accounts[rowIndex];
                          setState(() {
                            if (checkedAcs.contains(accountItem.accountName)) {
                              checkedAcs.remove(accountItem.accountName);
                            } else {
                              checkedAcs.add(accountItem.accountName);
                            }
                          });
                        })),
                SelectableText(accounts[rowIndex].accountName),
              ],
            ),
          ),
          rowIndex % 2 == 0 ? const Color(0x00f2f2f2) : const Color(0xfff2f2f2),
          alignment: Alignment.centerLeft),

      //     wrapColor(
      //   ,
      //   rowIndex % 2 == 0 ? const Color(0x00f2f2f2) : const Color(0xfff2f2f2),
      // ),
      contentCellBuilder: (int columnIndex, int rowIndex) {
        var accountItem = accounts[rowIndex];
        return wrapColor(
          buildItemView(accountItem, rowIndex, columnIndex),
          rowIndex % 2 == 0 ? const Color(0x00f2f2f2) : const Color(0xfff2f2f2),
        );
      },
    );
  }

  void loadPrePage() {
    if (page > 1) page--;
    reload();
  }

  void loadNextPage() {
    if (page < maxPage) page++;
    reload();
  }

  Widget buildItemView(
      AccountItemHolder accountItem, int rowIndex, int columnIndex) {
    switch (headerAt(columnIndex)) {
      case "账号":
        return SelectableText(accountItem.accountName);
      case "ID":
        return Text(accountItem.accountId);
      case "今日/总积分":
        return TextButton(
          onPressed: accountItem.scoreText == "无"
              ? null
              : () => showDetailScore(accountItem),
          child: Tooltip(
            message: accountItem.studyModeStr(),
            waitDuration: const Duration(milliseconds: 500),
            child: Text(
              accountItem.scoreText,
              style: TextStyle(
                color: accountItem.scoreText == "无"
                    ? Colors.redAccent
                    : const Color(0xFF67AD28),
              ),
            ),
          ),
        );
      // case "总积分":
      //   return Text(
      //       accountItem.scoreInfo != null ? "${accountItem.totalScore}" : "无");
      case "添加日期":
        var today = formatDate(DateTime.now(), format: "yy/MM/dd");
        var addDay = reformatDate(accountItem.addTime, format: "yy/MM/dd");
        return Text(
          reformatDate(accountItem.addTime,
              format: today == addDay ? "MM/dd HH:mm" : "yy/MM/dd"),
        );
      case "过期日期":
        var t = DateTime.now().add(const Duration(days: 2));
        var endTime = DateTime.parse(accountItem.validityDate);
        var mill = endTime.millisecondsSinceEpoch -
            DateTime.now().millisecondsSinceEpoch;
        String remainingText;
        var remainingDay = (mill / (24 * 60 * 60 * 1000)).round();
        if (mill < 0) {
          remainingText = "过期";
        } else {
          remainingText = "$remainingDay天";
        }
        var displayText = accountItem.validityDateFormatted;
        if (remainingDay <= 5) {
          displayText = reformatDate(
            accountItem.validityDate,
            format: "MM/dd HH:mm",
          );
        }
        return Align(
          alignment: Alignment.centerRight,
          child: AutoSizeText.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: "$remainingText ",
                  style: TextStyle(color: mill < 0 ? Colors.red : Colors.blue),
                ),
                TextSpan(
                  text: displayText,
                  style: endTime.isAfter(t)
                      ? null
                      : const TextStyle(color: Colors.red),
                ),
              ],
            ),
            maxLines: 1,
          ),
        );
      case "绑定设备":
        return Tooltip(
          message: accountItem.deviceInfo != null ? "更换设备" : "",
          waitDuration: const Duration(milliseconds: 500),
          child: TextButton(
            onPressed: accountItem.deviceInfo != null
                ? () {
                    showMessageDialog(
                        context, "确认更换设备？", "更换设备需消耗 3 积分。\n且需要重新发码登录",
                        actions: [
                          TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                requestChangeDevice(accountItem);
                              },
                              child: const Text("更换"))
                        ],
                        negText: "取消");
                  }
                : null,
            child: Text(
              accountItem.deviceText,
              textAlign: TextAlign.center,
              style: const TextStyle(fontFamily: "FiraMono"),
            ),
          ),
        );
      case "积分更新":
        return Text(accountItem.scoreDate);
      case "代理":
        return Text(accountItem.agent);
      case "状态":
        // var sc = accountItem.statusTextAndColor();
        var tv = Text(
          accountItem.statusText,
          style: TextStyle(
            color: Color(accountItem.statusColor),
          ),
        );
        if (["需要认证"].contains(accountItem.statusText)) {
          return Tooltip(
              message: "重置状态",
              child: TextButton(
                  child: tv,
                  onPressed: () {
                    accountItem.clearStatus(this);
                  }));
        }
        return tv;
      case "异常次数":
        if (accountItem.aberrantCnt > 0) {
          var s = accountItem.aberrantCnt.toString();
          if ((accountItem.aberrantRemindDate ?? "").isNotEmpty) {
            s += " (${accountItem.aberrantRemindDate})  ";
          }
          return TextButton(
            onPressed: () =>
                showAccountAberrantLogByUser(accountItem.accountName),
            child: Tooltip(
              message: "查看异常记录",
              child: Text(
                s,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.redAccent),
              ),
            ),
          );
        } else {
          return Text(accountItem.aberrantCnt.toString());
        }

      case "密码":
        return Text(accountItem.accountPwd ?? "");
      case "备注":
        var sct = TextEditingController(text: accountItem.remark ?? "");
        return TextField(
          enabled: !widget.viewMode,
          maxLength: 250,
          controller: sct,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 14),
          cursorHeight: 15,
          cursorWidth: 1.5,
          cursorColor: Colors.blueAccent,
          decoration:
              const InputDecoration(counterText: "", border: InputBorder.none),
          textInputAction: TextInputAction.go,
          onSubmitted: (_) async {
            var newRemark = sct.text.trim();
            accountItem.remark = newRemark;
            logging.d("submit: ${accountItem.accountId} $newRemark");
            try {
              var resp = await Http.postForm("/user/account/update_remark",
                  {"acc_id": accountItem.accountId, "remark": newRemark});
              if (mounted) {
                if (resp["code"] == 0) {
                  showSnackBar(context, "修改成功");
                } else {
                  showSnackBar(context, "修改失败：${resp["message"]}");
                }
              }
            } catch (e) {
              showSnackBar(context, "网络错误：$e");
            }
          },
        );
      case "操作":
        var pushText = accountItem.pushToken.isNotEmpty
            ? "推送 ${accountItem.pushToken.substring(0, min(4, accountItem.pushToken.length))}"
            : "推送 Token";
        var accountMenus = [
          "查看密码",
          "修改密码",
          "续费",
          "删除",
          pushText,
          if (widget.isAdmin) "信任设备",
          if (widget.isAdmin) "异常记录",
        ];

        var needLogin = accountItem.isValid && !accountItem.hadLogin;
        return Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Visibility(
              visible: needLogin,
              maintainSize: true,
              maintainAnimation: true,
              maintainState: true,
              child: TextButton(
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.all(2),
                  minimumSize: const Size(45, 30),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  alignment: Alignment.center,
                ),
                onPressed: () =>
                    accountItem.sendSms(this, accountItem.accountName),
                child: const Text("发码"),
              ),
            ),
            Visibility(
              visible: needLogin,
              maintainSize: true,
              maintainAnimation: true,
              maintainState: true,
              child: TextButton(
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.all(2),
                  minimumSize: const Size(45, 30),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  alignment: Alignment.center,
                ),
                onPressed: () => accountItem.requestLogin(this),
                child: const Text("登录"),
              ),
            ),
            PopupMenuButton(
              icon: const Icon(Icons.more_vert),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              itemBuilder: (context) => List.generate(
                accountMenus.length,
                (index) => PopupMenuItem(
                  value: MapEntry(index, accountMenus[index]),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20),
                    child: Text(
                      accountMenus[index],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
              onSelected: (MapEntry<int, String> item) async {
                switch (item.key) {
                  case 0:
                    await accountItem.displayPwd(this);
                    break;
                  case 1:
                    await accountItem.updatePwd(this);
                    break;
                  case 2:
                    await accountItem.renewalAccount(this);
                    break;
                  case 3:
                    await accountItem.requestDelAccount(this);
                    break;
                  case 4:
                    accountItem.setPushToken(this);
                    break;
                  case 5:
                    showAccountTrustLog(accountItem.accountName);
                    break;
                  case 6:
                    showAccountAberrantLog(accountItem.accountName);
                    break;
                }
              },
            ),
          ],
        );
    }
    return SizedBox(
      width: 100,
      child: Text("[ITEM $columnIndex,$rowIndex]"),
    );
  }

  void showAccountTrustLog(String phone) async {
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/admin/trust_device/search",
        queries: {"phone": phone});
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        showCommonList(
          context,
          "$phone 信任设备",
          resp['data']
              .map(
                (e) => ListTile(
                  title: Text("账号：${e['extra_info']} / id:${e["extra_id"]}"),
                  subtitle:
                      Text("时间： ${reformatDate(e["date"])}\n设备：${e['detail']}"),
                ),
              )
              .toList(),
        );
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  void allCheck(accounts) {
    setState(() {
      if (checkedAcs.length == accounts.length) {
        checkedAcs.clear();
      } else {
        checkedAcs.addAll(List.from(accounts.map((e) => e.accountName)));
      }
    });
  }

  void showAccountAberrantLogByUser(String phone) async {
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("/user/account/aberrant_list",
        queries: {"phone": phone});
    var types = {31: "账号异常", 32: "认证提醒", 33: "异常提醒"};
    if (mounted) {
      dialog.dismiss();
      if (resp['data'].length == 0) {
        showSnackBar(context, "无异常记录");
        return;
      }

      showDialogList(
        context,
        "异常提醒记录",
        List.from(resp['data'].map(
          (e) => ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text("日期：${e['detail'].split("/")[1]}"),
            subtitle: Text("记录日期：${reformatDate(e["date"])}"),
          ),
        )),
      );
    }
  }

  void showAccountAberrantLog(String phone) async {
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/admin/account/aberrant_msg/list",
        queries: {"phone": phone});
    var types = {31: "账号异常", 32: "认证提醒", 33: "异常提醒"};
    if (mounted) {
      dialog.dismiss();
      if (resp['data'].length == 0) {
        showSnackBar(context, "无异常记录");
        return;
      }
      showCommonList(
        context,
        "异常记录",
        resp['data']
            .map(
              (e) => ListTile(
                title: Text(
                  "【${types[e['type']] ?? e['type']}】 账号：${e['extra_info']}",
                ),
                subtitle:
                    Text("时间：${reformatDate(e["date"])}\n设备：${e['detail']}"),
              ),
            )
            .toList(),
      );
    }
  }

  void showDetailScore(AccountItemHolder accountItem) {
    var scoreDetail = "";
    logging.d(jsonEncode(accountItem.scoreInfo));
    var si = accountItem.scoreInfo;
    var shots = [];
    if (si != null) {
      try {
        if (si.containsKey("screenshots")) {
          shots = si["screenshots"];
        }
        scoreDetail += "今日/总积分：${si["today_score"]}/${si["total_score"]}\n\n";
        for (var item in si["items"]) {
          scoreDetail +=
              "${item["name"]}: ${item["score"]}/${item["scores"]}\n";
        }
      } catch (e) {
        logging.d(e);
      }
    }
    if (widget.isAdmin || widget.userStudyType == 1) {
      scoreDetail += "\n学习类型：${accountItem.studyModeStr()}";
    }
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("详细积分：${accountItem.accountName}"),
        content: Text(scoreDetail),
        actions: [
          if (shots.isNotEmpty)
            ...shots.asMap().entries.map((e) => TextButton(
                child: Text("截图${e.key + 1}"),
                onPressed: () {
                  launchUrl(Uri.parse(e.value),
                      mode: LaunchMode.externalApplication);
                })),
          if (accountItem.pushToken.isNotEmpty)
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                pushScore(accountItem.accountId);
              },
              child: const Text("发送消息通知"),
            )
          else
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                accountItem.setPushToken(this);
              },
              child: const Text("设置推送Token"),
            )
        ],
      ),
    );
  }

  void pushScore(String accId) async {
    var dialog = showLoadingDialog(context, title: "发送中");
    var resp = await Http.getJson("/user/account/push_score_msg",
        queries: {"acc_id": accId});
    dialog.dismiss();
    if (resp['code'] == 0) {
      if (mounted) {
        showSnackBar(context, "发送成功");
      }
    } else {
      if (mounted) {
        showSnackBar(context, "发送失败: ${resp["message"]}");
      }
    }
  }

  void exportOption() {
    bool desensitization = true;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("导出表格"),
        content: Row(
          children: [
            Checkbox(
                value: desensitization,
                onChanged: (v) {
                  desensitization = !desensitization;
                  (ctx as Element).markNeedsBuild();
                }),
            const Text("脱敏数据"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("取消"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              exportExcel(desensitization);
            },
            child: const Text("导出"),
          )
        ],
      ),
    );
  }

  void exportExcel(bool desensitization) async {
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("/user/account/excel", queries: {
      if (filterType != null) "filter_type": filterType!,
      "search_all": getAll ? "1" : "0",
      "desensitization": desensitization ? "1" : "0"
    });
    dialog.dismiss();
    if (resp['code'] == 0) {
      launchUrl(HttpTool.buildUrl(HttpTool.baseUrl, "/user/excel/${resp["data"]}"),
          mode: LaunchMode.externalApplication);
    } else {
      if (mounted) {
        showSnackBar(context, "生成失败: ${resp["message"]}");
      }
    }
  }

  void batchAddAccount() {
    var ctrl = TextEditingController();
    var enabled = false;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("批量添加账号"),
        content: SizedBox(
          height: 200,
          width: 300,
          child: TextField(
            autofocus: true,
            controller: ctrl,
            maxLines: 100,
            onChanged: (t) {
              enabled = t.trim().isNotEmpty;
              (ctx as Element).markNeedsBuild();
            },
            style: const TextStyle(fontSize: 12),
            decoration: const InputDecoration(
              hintText:
                  "每个账号密码天数按 ---- 隔开，每行一个账号: \n账号----密码----天数\n账号----密码----天数",
              labelText: "",
              border: OutlineInputBorder(),
              counterText: "",
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: !enabled
                ? null
                : () {
                    try {
                      var l = parseAccounts(ctrl.text);
                      if (l.isNotEmpty) {
                        Navigator.pop(ctx);
                        showMessageDialog(context, "确认账号信息",
                            "账号数量：${l.length}\n${l.join('\n')}",
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  batchReqAddAccount(l);
                                },
                                child: const Text("添加"),
                              )
                            ]);
                      }
                    } catch (e) {
                      showMessageDialog(ctx, "解析错误", e.toString());
                    }
                  },
            child: const Text("确认"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("取消"),
          ),
        ],
      ),
    );
  }

  String? getIdByName(String name, List<AccountItemHolder> accounts) {
    for (var acc in accounts) {
      if (acc.accountName == name) return acc.accountId;
    }
    return null;
  }

  void batchRenewal() {
    var enable = true;
    var ctrl = TextEditingController(text: "30");
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("批量续费"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("账号：\n${checkedAcs.join('\n')}"),
            const SizedBox(height: 10),
            TextField(
              controller: ctrl,
              autofocus: true,
              onChanged: (s) {
                enable = s.trim().isNotEmpty;
                (ctx as Element).markNeedsBuild();
              },
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: "天数 (1积分/天)"),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: enable
                ? () {
                    Navigator.pop(context);
                    doBatchRenewal(accounts, ctrl.text);
                  }
                : null,
            child: const Text("续费"),
          )
        ],
      ),
    );
  }

  void doBatchRenewal(List<AccountItemHolder> accounts, String day) async {
    var successCnt = 0;
    var msg = "天数：$day\n";
    for (var name in checkedAcs) {
      var accId = getIdByName(name, accounts) ?? "";
      var resp = await Http.getJson("/user/account/renewal",
          queries: {"day": day, "acc_id": accId});
      if (resp['code'] == 0) {
        successCnt++;
        msg += "$name 成功\n";
      } else {
        msg += "$name 失败：${resp['message']}\n";
      }
    }
    if (mounted) {
      showMessageDialog(context, "续费结果",
          "成功：$successCnt   失败：${checkedAcs.length - successCnt}\n$msg");
      refreshList(true);
    }
  }

  void doBatchDelete(List<String> acsName) async {
    var successCnt = 0;
    var msg = "";
    for (var name in acsName) {
      var resp = await Http.getJson("/user/account/disable/$name");
      if (!mounted) return;
      if (resp['code'] == 0) {
        msg += "$name: 成功\n";
        successCnt++;
      } else {
        msg += "$name: 失败：${resp['message']}\n";
      }
    }
    if (mounted) {
      showMessageDialog(context, "删除结果",
          "成功: $successCnt    失败: ${acsName.length - successCnt}\n$msg");
      refreshList();
    }
  }

  void batchDelete() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("确认删除？"),
        content: Text(
          checkedAcs.join("\n"),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text("取消")),
          TextButton(
              onPressed: () async {
                Navigator.pop(ctx);
                doBatchDelete(checkedAcs);
              },
              child: const Text(
                "删除",
                style: TextStyle(color: Colors.redAccent),
              ))
        ],
      ),
    );
  }

  void batchReqAddAccount(List<Acc> acs) async {
    var msg = "";
    var successCnt = 0;
    for (var acc in acs) {
      var resp = await Http.postForm("/user/account/add", {
        "name": acc.name,
        "pwd": acc.pwd,
        "day": acc.day.toString(),
        "remark": acc.remark
      });
      if (resp['code'] == 0) {
        msg += "${acc.name}: 成功\n";
        successCnt++;
      } else {
        msg += "${acc.name}: 失败：${resp['message']}\n";
      }
    }
    if (mounted) {
      showMessageDialog(context, "添加结果",
          "成功：$successCnt   失败：${acs.length - successCnt}\n$msg");
      refreshList();
    }
  }

  void addAccount() {
    var nameCtrl = TextEditingController();
    var pwdCtrl = TextEditingController();
    var dayCtrl = TextEditingController(text: "30");

    var remarkCtrl = TextEditingController();
    var tokenCtrl = TextEditingController();

    bool addEnable = false;
    void updateButtonStatus(ctx, String s) {
      var name = nameCtrl.text.trim();
      var pwd = pwdCtrl.text.trim();
      var day = dayCtrl.text.trim();
      setState(() {
        (ctx as Element).markNeedsBuild();
        addEnable = name.isNotEmpty && pwd.isNotEmpty && day.isNotEmpty;
      });
    }

    var studyMode = WrapVar(widget.isAdmin ? 0 : 1);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        scrollable: true,
        title: const Text("添加账号"),
        content: SizedBox(
          width: 270,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(width: 270),
              TextField(
                maxLength: 20,
                onChanged: (s) => updateButtonStatus(ctx, s),
                autofocus: true,
                controller: nameCtrl,
                decoration: const InputDecoration(
                  labelText: "账号",
                  border: OutlineInputBorder(),
                  counterText: "",
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                maxLength: 30,
                controller: pwdCtrl,
                onChanged: (s) => updateButtonStatus(ctx, s),
                decoration: const InputDecoration(
                  labelText: "密码",
                  border: OutlineInputBorder(),
                  counterText: "",
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                maxLength: 250,
                controller: remarkCtrl,
                decoration: const InputDecoration(
                  labelText: "备注(可选)",
                  border: OutlineInputBorder(),
                  counterText: "",
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                maxLength: 4,
                controller: dayCtrl,
                onChanged: (s) => updateButtonStatus(ctx, s),
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  labelText: "天数 (1积分/天)",
                  border: OutlineInputBorder(),
                  counterText: "",
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                maxLength: 50,
                controller: tokenCtrl,
                decoration: const InputDecoration(
                  labelText: "积分推送Token(可选)",
                  border: OutlineInputBorder(),
                  counterText: "",
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                "重要提示：请在添加账号前，请将账号的信任设备数量保留在1-2个，否则可能导致账号异常",
                style: TextStyle(color: Colors.red),
              ),
              Offstage(
                offstage: !(widget.isAdmin || widget.userStudyType == 1),
                child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: buildRadio(ctx, studyMode, "学习类型:  ",
                        [if (widget.isAdmin) "学满", "10分", "仅登录"])),
              )
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: addEnable
                ? () async {
                    var name = nameCtrl.text.trim();
                    var pwd = pwdCtrl.text.trim();
                    if (await doAddAccount(name, pwd, dayCtrl.text.trim(),
                        remarkCtrl.text.trim(), studyMode.get(), tokenCtrl.text.trim())) {
                      if (mounted) {
                        Navigator.pop(ctx);
                      }
                      refreshList();
                      widget.refreshUser?.call();
                    }
                  }
                : null,
            child: const Text("添加"),
          ),
        ],
      ),
    );
  }

  Future<bool> doAddAccount(
      String name, String pwd, String day, String remark, int studyMode, String pushToken) async {
    logging.d("add acc: $name $pwd $studyMode");
    var resp = await Http.postForm("/user/account/add", {
      "name": name,
      "pwd": pwd,
      "day": day,
      "remark": remark,
      "study_mode": studyMode.toString(),
      "push_token": pushToken
    });
    if (!mounted) return false;
    if (resp['code'] == 0) {
      showSnackBar(context, "添加成功");
      return true;
    } else {
      showSnackBar(context, "添加失败：${resp['message']}");
      return false;
    }
  }

  List<Acc> parseAccounts(String text) {
    if (text.isEmpty) throw ParseException("空内容");
    var a = text.split("\n");
    var list = <Acc>[];
    int line = 1;
    for (var v in a) {
      var a = v.trim().split("----");
      if (a.length < 3) {
        throw ParseException("格式错误(第$line行):\n$v");
      }
      String name = a[0].trim();
      String pwd = a[1].trim();
      int day = 0;
      try {
        day = int.parse(a[2].trim());
      } catch (e) {}
      String remark = "";
      if (a.length > 3) {
        remark = a[3];
      }
      if (name.isEmpty || pwd.isEmpty || day <= 0) {
        throw ParseException("数据错误(第$line行)：$v");
      }
      list.add(Acc(name, pwd, day, remark));
      line++;
    }
    return list;
  }

  void requestChangeDevice(AccountItemHolder accountItem) async {
    var accountId = accountItem.accountId;
    var d = showLoadingDialog(context);
    var resp = await Http.getJson("/user/account/reset_device",
        queries: {"aid": accountId});
    if (!mounted) return;
    if (resp['code'] == 0) {
      showSnackBar(context, "设备重置成功", duration: const Duration(seconds: 1));
      refreshList();
    } else {
      showSnackBar(context, "状态重置 失败：${resp['message']}");
    }
    d.dismiss();
  }
}

class ParseException implements Exception {
  final String message;

  ParseException(this.message);

  @override
  String toString() => message;
}

class Acc {
  final String name;
  final String pwd;
  final String remark;
  final int day;

  Acc(this.name, this.pwd, this.day, this.remark);

  @override
  String toString() {
    return '账号: $name, 密码: $pwd, 天数: $day, 备注: ${remark.isEmpty ? "无" : remark}';
  }
}

class AccountItemHolder {
  final Map<String, dynamic> accountInfo;
  final Function refreshList;

  AccountItemHolder(this.accountInfo, this.refreshList);

  String get accountName => accountInfo['name'];

  int? get accountStudyMode => accountInfo['study_mode'];

  String get addTime => (accountInfo['add_time']);

  String get pushToken => (accountInfo['push_token'] ?? "");

  String get addTimeFormatted =>
      reformatDate(accountInfo['add_time'], format: "yy/MM/dd");

  String get validityDate => accountInfo['validity_date'];

  String get validityDateFormatted =>
      reformatDate(accountInfo['validity_date'], format: "yy/MM/dd");

  dynamic get deviceInfo => accountInfo['device'];

  dynamic get deviceText => deviceInfo != null
      ? deviceInfo["device_id"]
          .substring(0, 6) // + " / " + deviceInfo["model"])
      : "无";

  String? get remark => accountInfo["remark"];

  set remark(String? value) {
    accountInfo["remark"] = value;
  }

  String studyModeStr() {
    var mode = accountStudyMode;
    if (mode == null || mode == 0) {
      return "学满";
    } else if (mode == 1) {
      return "10 分";
    } else if (mode == 2) {
      return "仅登录";
    }
    return mode.toString();
  }

  dynamic get hadLogin => deviceInfo != null && deviceInfo["had_login"];

  String get accountId => accountInfo['id'].toString();

  String? get accountPwd => accountInfo['pwd'];

  int get aberrantCnt => accountInfo['aberrant_cnt'];

  String? get aberrantRemindDate => accountInfo['aberrant_remind_date'];

  String get scoreText => accountInfo["score_text"];

  int get todayScore => scoreInfo != null ? scoreInfo['today_score'] : 0;

  int get totalScore => scoreInfo != null ? scoreInfo['total_score'] : 0;

  String get scoreDate => scoreInfo != null
      ? reformatDate(scoreInfo['update_date'], format: "HH:mm")
      : "无";

  dynamic get scoreInfo => accountInfo['today_score_info'];

  bool get isValid => accountInfo['validity_date'] == null
      ? false
      : DateTime.parse(validityDate).compareTo(DateTime.now()) > 0;

  String get agent => accountInfo["agent_user"].toString();

  String? get accountStatus => accountInfo["status"];

  String get statusText => accountInfo["display_status"];

  int get statusColor => accountInfo["status_color"];

  String? todayScoreInfo() {
    var si = accountInfo['today_score_info'];
    if (si == null) return null;
    return "今日积分：${si['today_score']}/${si['today_score_all'] ?? ""}  总积分：${si['total_score']}   更新日期：${si['date']}";
  }

  void requestLogin(State state) async {
    var ctrl = TextEditingController();
    var enabled = false;
    showDialog(
      context: state.context,
      builder: (ctx) => AlertDialog(
        title: const Text("登录"),
        content: SizedBox(
          width: 300,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("账号：$accountName"),
              const SizedBox(height: 10),
              TextField(
                autofocus: true,
                controller: ctrl,
                onChanged: (s) {
                  enabled = s.trim().length > 3;
                  (ctx as Element).markNeedsBuild();
                },
                decoration: const InputDecoration(labelText: "验证码"),
                onSubmitted: (s) {
                  if (enabled) {
                    Navigator.pop(ctx);
                    sendLoginRequest(state, ctrl.text.trim());
                  }
                },
              ),
              const SizedBox(height: 10),
              const Text(
                "若无验证码，请先使用【发码】功能获取验证码后再登录",
                style: TextStyle(color: Colors.blueGrey),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: enabled
                  ? () {
                      Navigator.pop(ctx);
                      sendLoginRequest(state, ctrl.text.trim());
                    }
                  : null,
              child: const Text("登录"))
        ],
      ),
    );
  }

  void setPushToken(State state) {
    showInputDialog(state.context, "推送 Token",
            message: "账号: $accountName",
            initText: accountInfo["push_token"] ?? "",
            labelText: "Token")
        .then((value) async {
      if (value != null && value.isNotEmpty) {
        var dialog = showLoadingDialog(state.context, title: "发送中");
        var resp = await Http.postForm("/user/account/update_push_token",
            {"acc_id": accountId, "push_token": value});
        dialog.dismiss();
        if (resp['code'] == 0) {
          if (state.mounted) {
            state.setState(() {
              accountInfo["push_token"] = value;
            });
            showSnackBar(state.context, "设置成功");
          }
        } else {
          if (state.mounted) {
            showSnackBar(state.context, "设置失败: ${resp["message"]}");
          }
        }
      }
    });
  }

  void sendLoginRequest(State state, String code) async {
    var dialog = showLoadingDialog(state.context);
    var resp = await Http.getJson("/user/account/request_login2",
        queries: {"aid": accountId, "code": code});
    dialog.dismiss();
    if (state.mounted) {
      if (resp["code"] == 0) {
        showSnackBar(state.context, "登录请求发送成功");
      } else {
        showSnackBar(state.context, resp["message"]);
      }
    }
  }

  Future<void> updatePwd(State state) async {
    var ctrl = TextEditingController();
    bool enabled = false;
    showDialog(
      context: state.context,
      builder: (ctx) => AlertDialog(
        title: const Text("修改密码"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("当前账号：$accountName"),
            Text("当前密码：$accountPwd"),
            TextField(
              autofocus: true,
              controller: ctrl,
              onChanged: (s) {
                enabled = s.trim().length > 3;
                (ctx as Element).markNeedsBuild();
              },
              decoration: const InputDecoration(labelText: "新密码"),
            )
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("取消"),
          ),
          TextButton(
            onPressed: enabled
                ? () async {
                    if (await doUpdatePwd(state, ctrl.text.trim())) {
                      Navigator.pop(ctx);
                    }
                  }
                : null,
            child: const Text("修改"),
          )
        ],
      ),
    );
  }

  Future<bool> doUpdatePwd(State state, String pwd) async {
    var resp = await Http.getJson("/user/account/update_pwd",
        queries: {"acc_id": accountId, "pwd": pwd});
    if (resp["code"] == 0) {
      if (state.mounted) {
        accountInfo['pwd'] = pwd;
        showSnackBar(state.context, "修改成功");
      }
      return true;
    } else {
      if (state.mounted) {
        showSnackBar(state.context, "修改失败：${resp['message']}");
      }
      return false;
    }
  }

  Future<void> displayPwd(State state) async {
    showDialog(
      context: state.context,
      builder: (ctx) => AlertDialog(
        title: Text(accountName),
        content: Text("密码：$accountPwd"),
        actions: [
          TextButton(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: accountPwd!));
                if (state.mounted) {
                  showSnackBar(ctx, "已复制");
                }
              },
              child: const Text("复制"))
        ],
      ),
    );
  }

  Future<void> requestDelAccount(State state) async {
    var diffMillis =
        DateTime.parse(accountInfo['validity_date']).millisecondsSinceEpoch -
            DateTime.now().millisecondsSinceEpoch;
    var day = DateTime.fromMillisecondsSinceEpoch(diffMillis)
            .millisecondsSinceEpoch ~/
        (3600000 * 24);
    var hasDeduct = accountInfo['has_deduct'];
    showDialog(
      context: state.context,
      builder: (ctx) => AlertDialog(
        title: const Text("确认删除？"),
        content: Text(
          "账号：$accountName${day > 0 && hasDeduct ? "\n预计回收积分: $day" : ""}\n删除后不可恢复",
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text("取消")),
          TextButton(
              onPressed: () async {
                Navigator.pop(ctx);
                await delAccount(state);
              },
              child: const Text(
                "删除",
                style: TextStyle(color: Colors.redAccent),
              ))
        ],
      ),
    );
  }

  Future<void> delAccount(State state) async {
    var resp = await Http.getJson("/user/account/disable/$accountName");
    if (!state.mounted) return;
    if (resp['code'] == 0) {
      showSnackBar(state.context, "删除成功", duration: const Duration(seconds: 1));
      refreshList();
    } else {
      showSnackBar(state.context, "删除失败：${resp['message']}");
    }
  }

  Future<void> clearStatus(State state) async {
    var resp = await Http.getJson("/user/account/reset_status",
        queries: {"aid": accountId});
    if (!state.mounted) return;
    if (resp['code'] == 0) {
      showSnackBar(state.context, "状态重置成功",
          duration: const Duration(seconds: 1));
      refreshList();
    } else {
      showSnackBar(state.context, "状态重置 失败：${resp['message']}");
    }
  }

  Future<void> renewalAccount(State state) async {
    var enable = true;
    var ctrl = TextEditingController(text: "30");
    showDialog(
      context: state.context,
      builder: (ctx) => AlertDialog(
        title: const Text("续费"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("账号：$accountName"),
            const SizedBox(height: 10),
            TextField(
              controller: ctrl,
              autofocus: true,
              onChanged: (s) {
                enable = s.trim().isNotEmpty;
                (ctx as Element).markNeedsBuild();
              },
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: "天数 (1积分/天)"),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: enable ? () => renewal(state, ctrl.text) : null,
            child: const Text("续费"),
          )
        ],
      ),
    );
  }

  void renewal(state, String day) async {
    var ctx = state.context;
    Navigator.pop(ctx);
    var ld = showLoadingDialog(ctx);
    var resp = await Http.getJson("/user/account/renewal",
        queries: {"day": day, "acc_id": accountInfo["id"].toString()});
    if (!state.mounted) return;
    if (resp['code'] == 0) {
      ld.dismiss();
      showSnackBar(ctx, "续费成功");
      refreshList(true);
    } else {
      ld.dismiss();
      showSnackBar(ctx, "操作失败：${resp['message']}");
    }
  }

  sendSms(State state, String phone) async {
    var ctx = state.context;
    var d = showLoadingDialog(ctx);
    var resp = await Http.getJson("/user/send_code", queries: {"phone": phone});
    d.dismiss();
    if (!state.mounted) return;
    if (resp['code'] == 0) {
      showSnackBar(ctx, "已加入队列，请等待验证码");
    } else {
      showSnackBar(ctx, "请求失败：${resp['message']}");
    }
  }
}
