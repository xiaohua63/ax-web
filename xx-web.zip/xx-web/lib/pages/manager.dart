import 'dart:async';

import 'package:disable_screenshots/disable_screenshots.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:xx_study/components/alert_dialog.dart';
import 'package:xx_study/components/input_dialog.dart';
import 'package:xx_study/components/round_app_bar.dart';

import '../components/base_state.dart';
import '../components/nav_bar.dart';
import '../tools/config.dart';
import '../tools/http.dart';
import '../tools/logger.dart';
import '../tools/ui_utils.dart';
import '../tools/utils.dart';
import '../tools/ws.dart';
import 'accounts.dart';
import 'admin.dart';
import 'agent.dart';
import 'device.dart';
import 'home.dart';

class ManagerPage extends StatefulWidget {
  const ManagerPage({super.key});

  @override
  State createState() {
    return ManagerState();
  }
}

const double narrowScreenWidthThreshold = 450;

class ManagerState extends State<ManagerPage> implements EventListener {
  var menus = ["充值", "余额记录", "修改密码", "设置接口地址", "注销"];
  int screenIndex = 0;
  int screenMode = 0; //0- 1|
  Map<String, dynamic>? userInfo;
  int userInfoStatus = BaseState.statusLoading;
  bool isAdmin = false;
  List<Widget> fragments = [];
  var pageCtrl = PageController();
  List<NavigationDestination> navItems = l2Destinations;

  final DisableScreenshots _plugin = DisableScreenshots();

  Timer? timer;

  void requestLogout() {
    AlertDialog dialog = AlertDialog(
      title: const Text("确认退出?"),
      actions: [
        TextButton(
          child: const Text("取消"),
          onPressed: () => Navigator.pop(context), //关闭对话框
        ),
        TextButton(
          style: TextButton.styleFrom(foregroundColor: Colors.blue.shade500),
          child: const Text("退出"),
          onPressed: () {
            Navigator.pop(context, true); //关闭对话框
            logout();
          },
        ),
      ],
    );
    showDialog(context: context, builder: (context) => dialog);
  }

  @override
  void onTokenInvalid() {
    userInfo = null;
    AppSocket.stop();
    userInfoStatus == BaseState.statusError;
    if (mounted) {
      setState(() {});
      showSnackBar(context, "登录信息过期，请重新登录",
          duration: const Duration(days: 10), actionText: "登录", action: () {
        AppConfig.logout();
        Navigator.popAndPushNamed(context, "/login");
      });
    }
  }

  @override
  void onConnectStatusChanged() {
    logging.d("ConnectStatusChanged[$hashCode] ws running: "
        "${AppSocket.running} connected: ${AppSocket.connected}");
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void onAccountLoginSuccess(dynamic data) {
    var success = data["success"];
    var phone = data["name"];
    showAlert(context,
        title: success ? "登录成功！" : "登录失败，请重试",
        content: "账号：$phone\n${(success ? "" : data["reason"])}",
        onConfirm: () {
      return true;
    });
  }

  Future<void> loadUserInfo() async {
    try {
      userInfoStatus = BaseState.statusLoading;
      dynamic resp = await Http.getUserInfo();
      userInfo = null;
      if (resp['code'] == 0) {
        userInfoStatus = BaseState.statusSuccess;
        userInfo = resp['data'];
        /*if (userInfo!['is_admin']) {
          navItems = adminDestinations;
        } else*/ if (userInfo!["has_agent_permission"]) {
          navItems = l1Destinations;
        } else {
          navItems = l2Destinations;
        }
        if (mounted) {
          updateWatermark();
        }
        updateFragments();
        if (mounted) {
          Future.delayed(const Duration(seconds: 1), () {
            AppSocket.start(this);
          });
        }
      } else if (resp['code'] == -9) {
        userInfoStatus = BaseState.statusError;
        AppSocket.stop();
        if (mounted) {
          showSnackBar(context, '登录过期', actionText: '重新登录', action: () {
            AppConfig.logout();
            Navigator.pushReplacementNamed(context, "/login");
          });
        }
      } else {
        if (mounted) {
          showSnackBar(context, '请求失败 ${resp['message']}',
              actionText: "重试", action: loadUserInfo);
        }
      }
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      userInfoStatus = BaseState.statusError;
      if (mounted) {
        setState(() {});
        showSnackBar(context, '请求失败 $e',
            actionText: "重试", action: loadUserInfo);
      }
    }
  }

  @override
  void initState() {
    super.initState();
    updateFragments();
    checkAppEnabledAndExit(context).then((value) {
      if (value) {
        loadUserInfo();
      }
    });
    timer = Timer.periodic(
      const Duration(seconds: 30),
      (timer) {
        updateWatermark();
      },
    );
    // if (!kIsWeb) {
    //   _plugin.disableScreenshots(true);
    // }
  }

  void updateWatermark() {
    if (mounted && userInfo != null) {
      MediaQueryData? qd;
      try {
        qd = MediaQuery.maybeOf(context);
      } catch (e) {
        return;
      }
      if (qd == null) return;
      var screenWidth = qd.size.width;
      var screenHeight = qd.size.height;
      // logging.d("screenSize: $screenWidth $screenHeight");

      var un = userInfo!["user_name"];
      var d = formatDate(DateTime.now());
      var watermarkText = un + " " + d;
      // logging.d("updateWatermark: $watermarkText");
      _plugin.removeWatermark();
      _plugin.addWatermark(
        context,
        watermarkText,
        rowCount: screenWidth ~/ 180,
        columnCount: screenHeight ~/ 180,
        textStyle: const TextStyle(
          fontSize: 15,
          fontFamily: null,
          fontWeight: FontWeight.w700,
          color: Color(0x0B000000),
          decoration: TextDecoration.none,
        ),
      );
    }
  }

  void onMenuSelect(int index) async {
    switch (menus[index]) {
      case "充值":
        recharge();
        break;
      case "修改密码":
        changePwd();
        break;
      case "注销":
        requestLogout();
        break;
      case "余额记录":
        await getBalanceLog();
        break;
      case "设置接口地址":
        setNewHostUrl();
        break;
    }
  }

  Future<void> getBalanceLog() async {
    var resp = await Http.getJson("/user/balance_log");
    var data = resp['data'];
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => Scaffold(
        backgroundColor: Colors.transparent,
        appBar: RoundAppBar(
          leading: const CloseButton(),
          title: const Text("余额记录"),
        ),
        body: ListView.builder(
          itemCount: data.length,
          itemBuilder: (ctx, i) => ListTile(
            title: Text(data[i]['detail']),
            subtitle: Text(reformatDate(data[i]['date'])),
          ),
        ),
      ),
    );
  }

  void changePwd() {
    var rawCtrl = TextEditingController();
    var p1Ctrl = TextEditingController();
    var p2Ctrl = TextEditingController();

    bool enabled = false;

    void onTextUpdate(ctx, String _) {
      setState(() {
        enabled = rawCtrl.text.trim().isNotEmpty &&
            p1Ctrl.text.trim().isNotEmpty &&
            p2Ctrl.text.trim().isNotEmpty;
        (ctx as Element).markNeedsBuild();
      });
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("修改密码"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: rawCtrl,
              onChanged: (s) => onTextUpdate(ctx, s),
              decoration: const InputDecoration(labelText: "原密码"),
            ),
            TextField(
              controller: p1Ctrl,
              onChanged: (s) => onTextUpdate(ctx, s),
              decoration: const InputDecoration(labelText: "新密码"),
            ),
            TextField(
              controller: p2Ctrl,
              onChanged: (s) => onTextUpdate(ctx, s),
              decoration: const InputDecoration(labelText: "重复新密码"),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: enabled
                  ? () async {
                      String raw = rawCtrl.text.trim();
                      String new1 = p1Ctrl.text.trim();
                      String new2 = p2Ctrl.text.trim();
                      if (new1 != new2) {
                        showSnackBar(ctx, "新密码两次输入不同");
                        return;
                      }
                      if (await doChangePwd(raw, new1)) {
                        Navigator.pop(ctx);
                      }
                    }
                  : null,
              child: const Text("修改"))
        ],
      ),
    );
  }

  Future<bool> doChangePwd(String raw, String newP) async {
    newP = signPwd(newP);
    raw = signPwd(raw);
    var resp = await Http.postForm(
        "/user/change_pwd", {"old_pwd": raw, "new_pwd": newP});
    if (resp['code'] == 0) {
      if (mounted) {
        showSnackBar(context, "修改成功");
      }
      return true;
    } else {
      if (mounted) {
        showSnackBar(context, "修改失败：${resp['message']}");
      }
      return false;
    }
  }

  void recharge() {
    var codeCtrl = TextEditingController();
    bool active = false;
    void update(ctx, String s) {
      setState(() {
        active = s.isNotEmpty;
        (ctx as Element).markNeedsBuild();
      });
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("充值"),
        content: TextField(
          controller: codeCtrl,
          onChanged: (s) => update(ctx, s),
          decoration: const InputDecoration(labelText: "激活码"),
        ),
        actions: [
          TextButton(
              onPressed: active
                  ? () async {
                      if (await rechargeWithCode(codeCtrl.text)) {
                        Navigator.pop(ctx);
                      }
                    }
                  : null,
              child: const Text("激活"))
        ],
      ),
    );
  }

  Future<bool> rechargeWithCode(String code) async {
    var resp = await Http.getJson("/user/recharge", queries: {"code": code});
    if (resp['code'] == 0) {
      if (mounted) {
        showSnackBar(context, "充值成功");
      }
      await loadUserInfo();
      return true;
    } else {
      if (mounted) {
        showSnackBar(context, "充值失败：${resp['message']}");
      }
      return false;
    }
  }

  void logout() async {
    AppSocket.stop();
    AppConfig.logout();
    Navigator.of(context).pushReplacementNamed("/login");
  }

  @override
  void dispose() {
    AppSocket.stop();
    logging.d("dispose...");
    super.dispose();
    timer?.cancel();
  }

  PreferredSizeWidget createAppBar() {
    var userInfoText = userInfo == null
        ? ""
        : "${userInfo!["user_name"]} / 余额：${userInfo!['balance']}";
    return AppBar(
      leading: navItems[screenIndex].icon,
      title: Text(navItems[screenIndex].label),
      elevation: 10,
      automaticallyImplyLeading: false,
      actions: [
        Center(
            child: userInfoStatus != BaseState.statusSuccess
                ? TextButton(
                    onPressed: userInfoStatus == BaseState.statusLoading
                        ? null
                        : loadUserInfo,
                    child: Text(userInfoStatus == BaseState.statusLoading
                        ? "..."
                        : "刷新"),
                  )
                : Text(
                    userInfoText,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  )),
        const SizedBox(width: 15),
        Center(
          child: Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
                color: AppSocket.running
                    ? (AppSocket.connected
                        ? Colors.greenAccent
                        : Colors.blueAccent)
                    : Colors.redAccent,
                borderRadius: const BorderRadius.all(Radius.circular(5))),
          ),
        ),
        const SizedBox(width: 15),
        IconButton(
          onPressed: loadUserInfo,
          tooltip: "刷新",
          icon: const CircleAvatar(
            backgroundImage:
                NetworkImage("https://i0.imgs.ovh/2023/11/15/nxdDI.jpeg"),
          ),
        ),
        const SizedBox(width: 15),
        PopupMenuButton(
          icon: const Icon(Icons.more_vert),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          itemBuilder: (context) {
            return List.generate(
              menus.length,
              (index) {
                return PopupMenuItem(
                  value: index,
                  child: Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Text(
                        menus[index],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      )),
                );
              },
            );
          },
          onSelected: onMenuSelect,
        ),
        const SizedBox(width: 15),
      ],
    );
  }

  void updateFragments() {
    fragments.clear();
    for (NavigationDestination item in navItems) {
      fragments.add({
            "首页": HomePage(loadUserInfo),
            "账号管理": AccountsPage(userInfo?["is_admin"] ?? false,
                userInfo?["study_mode"] ?? 0, screenMode, loadUserInfo),
            "我的代理": AgentManagePage(loadUserInfo,
                userInfo?["is_admin"] ?? false, userInfo?["study_mode"] ?? 0),
          }[item.label] ??
          Text("未知：${item.label}"));
    }
  }

  Widget createPageView(int index) {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      pageCtrl.jumpToPage(screenIndex);
    });
    return PageView(
      physics: const NeverScrollableScrollPhysics(),
      controller: pageCtrl,
      children: fragments,
      onPageChanged: (i) {
        setState(() {});
      },
    );
  }

  void handleScreenChanged(int selectedScreen) {
    screenIndex = selectedScreen;
    pageCtrl.jumpToPage(screenIndex);
  }

  @override
  Widget build(BuildContext context) {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      updateWatermark();
    });
    var pageView = createPageView(screenIndex);
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth < narrowScreenWidthThreshold) {
        screenMode = 1;
        // 竖屏
        return Scaffold(
          appBar: createAppBar(),
          body: pageView,
          bottomNavigationBar: NavigationBars(
            onSelectItem: handleScreenChanged,
            selectedIndex: screenIndex,
            appBarDestinations: navItems,
          ),
        );
      } else {
        screenMode = 0;
        return Scaffold(
          appBar: createAppBar(),
          body: SafeArea(
            bottom: false,
            top: false,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: NavigationRailSection(
                    onSelectItem: handleScreenChanged,
                    selectedIndex: screenIndex,
                    appBarDestinations: navItems,
                  ),
                ),
                const VerticalDivider(thickness: 1, width: 1),
                Expanded(child: pageView)
              ],
            ),
          ),
        );
      }
    });
  }

  void setNewHostUrl() {
    showInputDialog(context, "设置接口地址", initText: HttpTool.baseUrl)
        .then((value) {
      if (value != null) {
        AppConfig.setHostUrl(value);
        HttpTool.baseUrl = value;
      }
    });
  }
}
