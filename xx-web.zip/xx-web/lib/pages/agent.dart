import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:xx_study/tools/logger.dart';

import '../components/base_state.dart';
import '../components/expandable_search_bar.dart';
import '../components/sticky_table/custom_properties/cell_dimensions.dart';
import '../components/sticky_table/sticky_headers_table.dart';
import '../tools/http.dart';
import '../tools/ui_utils.dart';
import '../tools/utils.dart';

class AgentManagePage extends StatefulWidget {
  final Function refreshUser;
  final bool isAdmin;
  final int userStudyType;

  const AgentManagePage(this.refreshUser, this.isAdmin, this.userStudyType,
      {super.key});

  @override
  State createState() => AgentState();
}

class AgentState extends BaseState<AgentManagePage> {
  var headers = ["余额", "账号数量", "添加日期", "状态", "操作"];

  var searchText = "";

  var searchAll = false;

  @override
  Widget buildLoadingView() {
    return buildSuccessView([]);
  }

  @override
  Widget buildSuccessView(data) {
    List<dynamic> agents =
        data.map((e) => AgentItemView(e, widget.refreshUser)).toList();

    return StickyHeadersTable(
      showHorizontalScrollbar: false,
      showVerticalScrollbar: false,
      legendCell: wrapColor(const Text("账号"), const Color(0xfff2f2f2)),
      columnsLength: headers.length,
      rowsLength: agents.length,
      cellDimensions: const CellDimensions.variableColumnWidth(
          columnWidths: [80, 80, 150, 80, 80],
          contentCellHeight: 50,
          stickyLegendWidth: 150,
          stickyLegendHeight: 50),
      columnsTitleBuilder: (int columnIndex) {
        return wrapColor(Text(headers[columnIndex]), const Color(0xfff0f0f0));
      },
      rowsTitleBuilder: (int rowIndex) {
        return wrapColor(
          Text(agents[rowIndex].name),
          rowIndex % 2 == 0 ? const Color(0x00f2f2f2) : const Color(0xfff2f2f2),
        );
      },
      contentCellBuilder: (int columnIndex, int rowIndex) {
        var agentItem = agents[rowIndex] as AgentItemView;
        return wrapColor(
            buildItemView(agentItem, rowIndex, columnIndex),
            rowIndex % 2 == 0
                ? const Color(0x00f2f2f2)
                : const Color(0xfff2f2f2));
      },
    );
  }

  Widget buildItemView(AgentItemView agentItem, int row, int col) {
    switch (headers[col]) {
      case "余额":
        return Text(agentItem.balance.toString());
      case "添加日期":
        return Text(agentItem.createDate);
      case "状态":
        return TextButton(
          onPressed: () => agentItem.setAgentEnabled(this, !agentItem.enabled),
          child: Text(
            agentItem.enabled ? "可用" : "已禁用",
            style: TextStyle(
              color: agentItem.enabled ? Colors.blueAccent : Colors.redAccent,
            ),
          ),
        );
      case "账号数量":
        return Text(agentItem.accountCount.toString());
      case "操作":
        return TextButton(
          onPressed: agentItem.enabled ? () => agentItem.recharge(this) : null,
          child: const Text("充值"),
        );
    }
    return Text("${agentItem.data}");
  }

  @override
  Widget buildScaffold(Widget child) {
    var searchCtrl = TextEditingController(text: searchText);
    return Scaffold(
      floatingActionButton: fabAnimateWrap(
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [],
        ),
      ),
      body: Column(
        children: [
          Expanded(child: child),
          if (currentStatus == BaseState.statusLoading)
            Expanded(child: super.buildLoadingView()),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding:
                const EdgeInsets.only(left: 20, top: 8, bottom: 8, right: 30),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ExpandableSearchBar(
                  iconSize: 40,
                  textSize: 13,
                  backgroundColor: Theme.of(context).colorScheme.background,
                  animationDuration: const Duration(milliseconds: 300),
                  hintText: "账号搜索",
                  onSubmitted: (s) {
                    searchText = s.trim();
                    reload();
                  },
                  editTextController: searchCtrl,
                ),
                const SizedBox(width: 10),
                FloatingActionButton.small(
                  backgroundColor: Theme.of(context).colorScheme.background,
                  shape: const CircleBorder(),
                  onPressed: addAgentUser,
                  tooltip: "添加代理",
                  child: const Icon(Icons.add),
                ),
                const SizedBox(width: 10),
                FloatingActionButton.small(
                  tooltip: "刷新",
                  backgroundColor: Theme.of(context).colorScheme.background,
                  shape: const CircleBorder(),
                  onPressed: reload,
                  child: const Icon(Icons.sync),
                ),
                if (widget.isAdmin) const SizedBox(width: 10),
                if (widget.isAdmin)
                  Checkbox(
                    value: searchAll,
                    onChanged: (v) {
                      searchAll = v ?? false;
                      reload();
                    },
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void addAgentUser() {
    var nameCtrl = TextEditingController();
    var pwdCtrl = TextEditingController();
    var balCtrl = TextEditingController();
    balCtrl.text = "20";
    var enabled = false;
    void onChanged(ctx, _) {
      enabled = nameCtrl.text.trim().isNotEmpty &&
          pwdCtrl.text.trim().length > 5 &&
          balCtrl.text.isNotEmpty;
      (ctx as Element).markNeedsBuild();
    }

    var agentType = WrapVar(0);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("添加代理"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              autofocus: true,
              controller: nameCtrl,
              maxLength: 16,
              onChanged: (s) => onChanged(ctx, s),
              decoration: const InputDecoration(
                labelText: "登录名",
                border: OutlineInputBorder(),
                counterText: "",
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              maxLength: 16,
              controller: pwdCtrl,
              onChanged: (s) => onChanged(ctx, s),
              decoration: const InputDecoration(
                labelText: "密码",
                border: OutlineInputBorder(),
                counterText: "",
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: balCtrl,
              maxLength: 5,
              keyboardType: TextInputType.number,
              onChanged: (s) => onChanged(ctx, s),
              decoration: const InputDecoration(
                labelText: "赠送余额",
                border: OutlineInputBorder(),
                counterText: "",
              ),
            ),
            Offstage(
                offstage: !(widget.isAdmin),
                child: buildRadio(ctx, agentType, "代理类型:  ", ["A", "B"]))
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text("取消")),
          TextButton(
              onPressed: enabled
                  ? () async {
                      if (await reqAddAgentUser(
                          nameCtrl.text.trim(),
                          pwdCtrl.text.trim(),
                          balCtrl.text.trim(),
                          agentType.get())) {
                        Navigator.pop(ctx);
                      }
                    }
                  : null,
              child: const Text("添加")),
        ],
      ),
    );
  }

  Future<bool> reqAddAgentUser(
      String name, String pwd, String bal, int studyMode) async {
    var resp = await Http.postForm("/user/agent/add", {
      "name": name,
      "pwd": signPwd(pwd),
      "bal": bal,
      "study_mode": studyMode.toString()
    });
    if (resp['code'] == 0) {
      if (mounted) {
        showSnackBar(context, "添加成功");
        reload();
        widget.refreshUser();
      }
      return true;
    } else {
      if (mounted) {
        showSnackBar(context, "添加失败：${resp['message']}");
      }
      return false;
    }
  }

  @override
  Future<void> onLoad() async {
    var resp = await Http.getJson("/user/agent/list", queries: {
      "search_text": searchText,
      "search_all": searchAll ? "1" : "0"
    });
    if (resp['code'] == 0) {
      var data = resp['data'];
      if (data.isEmpty) {
        notifyError("无数据");
      } else {
        notifySuccess(data);
      }
    } else {
      notifyError("获取失败: ${resp['message']}");
    }
  }

  @override
  bool get wantKeepAlive => true;
}

class AgentItemView {
  final dynamic data;
  final Function refreshUser;

  AgentItemView(this.data, this.refreshUser);

  String get id => data['id'].toString();

  String get name => data['user_name'];

  int get balance => data['balance'];

  String get createDate => reformatDate(data['create_date']);

  bool get enabled => data['enabled'];

  int get accountCount => data['account_count'];

  Future<void> setAgentEnabled(State state, bool enabled) async {
    dynamic goon = await showDialog(
      context: state.context,
      builder: (ctx) => AlertDialog(
        title: Text(enabled ? "确认启用代理？" : "确认禁用代理？"),
        content: Text("代理账号：$name\n${enabled ? "" : "积分将被回收至上级账户"}"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text("取消")),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text("确定")),
        ],
      ),
    );

    if (goon == null || !goon) return;

    var resp = await Http.getJson(
        enabled ? "/user/agent/enable" : "/user/agent/disable",
        queries: {"agent_id": id});
    if (resp['code'] == 0) {
      data['enabled'] = enabled;
      if (state.mounted) {
        state.setState(() {});

        showSnackBar(state.context, "操作成功");
      }
    } else {
      if (state.mounted) {
        showSnackBar(state.context, resp["message"]);
      }
    }
  }

  // @override
  // Widget build(BuildContext context) {
  //   return ListTile(
  //     title: Text("账号：$name"),
  //     subtitle: Text("余额: $balance \t创建日期: ${reformatDate(createDate)}"),
  //     trailing: Row(
  //       mainAxisSize: MainAxisSize.min,
  //       children: [
  //         TextButton(
  //           onPressed: () async => await setAgentEnabled(!enabled),
  //           child: Text(
  //             enabled ? "禁用" : "启用",
  //             style: TextStyle(
  //               color: enabled ? Colors.redAccent : Colors.blueAccent,
  //             ),
  //           ),
  //         ),
  //         TextButton(
  //           onPressed: enabled ? recharge : null,
  //           child: const Text("充值"),
  //         )
  //       ],
  //     ),
  //   );
  // }

  void recharge(State state) {
    var ctrl = TextEditingController();
    var enabled = false;
    void update(ctx, String s) {
      enabled = s.trim().isNotEmpty;
      (ctx as Element).markNeedsBuild();
    }

    showDialog(
        context: state.context,
        builder: (ctx) => AlertDialog(
              title: const Text("余额充值"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("账号：$name"),
                  SizedBox(height: 10),
                  TextField(
                    autofocus: true,
                    controller: ctrl,
                    onChanged: (s) => update(ctx, s),
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    maxLength: 5,
                    decoration: const InputDecoration(
                      labelText: "充值数量",
                      border: OutlineInputBorder(),
                      counterText: "",
                    ),
                  )
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text("取消"),
                ),
                TextButton(
                  onPressed: enabled
                      ? () async {
                          Navigator.pop(ctx);
                          await doRecharge(state, ctrl.text);
                        }
                      : null,
                  child: const Text("确认"),
                )
              ],
            ));
  }

  Future<void> doRecharge(State state, count) async {
    var resp = await Http.getJson("/user/agent/recharge",
        queries: {"agent_id": id, "count": count});
    if (resp["code"] == 0) {
      refreshUser();
      data['balance'] = resp['data'];
      if (state.mounted) {
        showSnackBar(state.context, "充值成功");
      }
    } else {
      if (state.mounted) {
        showSnackBar(state.context, "充值失败: ${resp['message']}");
      }
    }
  }
}
