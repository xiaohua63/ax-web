import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:convert';

import 'package:intl/intl.dart';

import '../main.dart';

String reverse(String input) {
  return input.split('').reversed.join();
}

String signPwd(String pwd) {
  return calcMd5("${reverse(pwd)}$pwd~_=");
}

String calcMd5(String data) {
  return md5.convert(utf8.encode(data)).toString();
}

String base64Encode(String input) {
  final bytes = utf8.encode(input);
  return base64.encode(bytes);
}

String formatDate(DateTime dateTime, {String format = "yy/MM/dd HH:mm"}) {
  return DateFormat(format).format(dateTime);
}

String reformatDate(String? d, {String format = "yy/MM/dd HH:mm"}) {
  if (d == null) return "null";
  var dd = DateTime.parse(d);
  return formatDate(dd, format: format);
}

Future<bool> checkAppEnabledAndExit(context) {
  return Future.sync(() async {
    if (!AxApp.appEnabled) {
      Future.delayed(const Duration(milliseconds: 100), () {
        Navigator.popAndPushNamed(context, "/");
      });
      return false;
    }
    return true;
  });
}


Widget fabAnimateWrap2(visible, child, {int aniDuration = 500}) {
  var duration = Duration(milliseconds: aniDuration);
  return AnimatedSlide(
    curve: Curves.fastOutSlowIn,
    duration: duration,
    offset: visible ? Offset.zero : const Offset(2, 0),
    child: child,
  );
}

extension PlatformExt on Platform {
  static bool get isMobile => !kIsWeb && (Platform.isIOS || Platform.isAndroid);
}
