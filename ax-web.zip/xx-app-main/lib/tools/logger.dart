import 'package:flutter/foundation.dart';

class Logger {
  void d(Object? obj) {
    if (kDebugMode) {
      print(obj);
    }
  }
}

var logging = Logger();

void d(Object? obj) => logging.d(obj);
