import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:xx_study/tools/logger.dart';

import '../tools/config.dart';

class HttpTool {
  static String baseUrl = '';
  static String AdminUrl = '';

  static String get baseUrlNoHttp =>
      baseUrl.replaceFirst("https://", "").replaceFirst("http://", "");

  // static String baseUrl = '127.0.0.1:8200';
  static Uri buildUrl(
    String baseUrl, [
    String unencodedPath = "",
    Map<String, dynamic>? queryParameters,
  ]) {
    if (unencodedPath.startsWith("https://")) {
      var u = Uri.parse(unencodedPath);
      return Uri.https(u.authority, u.path, queryParameters);
    }
    if (unencodedPath.startsWith("http://")) {
      var u = Uri.parse(unencodedPath);
      return Uri.http(u.authority, u.path, queryParameters);
    }
    if (baseUrl.startsWith("https://")) {
      return Uri.https(
          baseUrl.replaceFirst("https://", ""), unencodedPath, queryParameters);
    } else if (baseUrl.startsWith("http://")) {
      return Uri.http(
          baseUrl.replaceFirst("http://", ""), unencodedPath, queryParameters);
    }
    throw Exception("error baseUrl: $baseUrl");
  }

  Future<Uri> _buildUri(String path, {Map<String, String>? queries}) async {
    Map<String, dynamic> queryParameters = queries ?? {};
    if (await AppConfig.isLogin()) {
      queryParameters["token"] = await AppConfig.token();
    }
    return buildUrl(baseUrl, path, queryParameters);
  }

  dynamic getJson(String path,
      {Map<String, String>? headers,
      Map<String, String>? queries,
      bool holdError = true}) async {
    try {
      return await _getJson(path, headers, queries, holdError);
    } catch (e) {
      logging.d({path: e});
      if (!holdError) rethrow;
      if (e is TimeoutException) {
        return {"code": -1, "message": "请求超时"};
      } else if (e is http.ClientException) {
        return {"code": -1, "message": "网络错误，请重试"};
      }
      return {"code": -1, "message": "发生错误 $e"};
    }
  }

  dynamic _getJson(String path, Map<String, String>? headers,
      Map<String, String>? queries, bool throwError) async {
    Uri uri = await _buildUri(path, queries: queries);
    http.Response resp = await http
        .get(uri, headers: buildHeaders(headers: headers))
        .timeout(const Duration(seconds: 8));

    String respBody = utf8.decode(resp.bodyBytes);
    // logging.d("GET $uri\n==>${resp.statusCode} $respBody");
    return jsonDecode(respBody);
  }

  dynamic postForm(String path, Map<String, String> forms,
      {bool holdError = true, Map<String, String>? queries}) async {
    Uri uri = await _buildUri(path, queries: queries);
    try {
      http.Response resp = await http
          .post(uri, headers: buildHeaders(), body: forms)
          .timeout(const Duration(seconds: 8));
      String respBody = utf8.decode(resp.bodyBytes);
      // logging.d("POST $uri\n$forms\n==>$respBody");
      return jsonDecode(respBody);
    } catch (e) {
      logging.d({path: e});
      if (!holdError) rethrow;
      if (e is TimeoutException) {
        return {"code": -1, "message": "请求超时"};
      } else if (e is http.ClientException) {
        return {"code": -1, "message": "网络错误，请重试"};
      }
      return {"code": -1, "message": "发生错误 $e"};
    }
  }

  dynamic postJson(String path, Object data,
      {bool holdError = true, Map<String, String>? queries}) async {
    Uri uri = await _buildUri(path, queries: queries);
    try {
      http.Response resp = await http
          .post(
            uri,
            headers: {...buildHeaders(), "Content-Type": "application/json"},
            body: jsonEncode(data),
          )
          .timeout(const Duration(seconds: 5));
      String respBody = utf8.decode(resp.bodyBytes);
      // logging.d("POST $uri\n$forms\n==>$respBody");
      return jsonDecode(respBody);
    } catch (e) {
      logging.d({path: e});
      if (!holdError) rethrow;
      if (e is TimeoutException) {
        return {"code": -1, "message": "请求超时"};
      } else if (e is http.ClientException) {
        return {"code": -1, "message": "网络错误，请重试"};
      }
      return {"code": -1, "message": "发生错误 $e"};
    }
  }

  dynamic getUserInfo() {
    return getJson("/user/info");
  }

  dynamic login(String name, String pwd) =>
      postForm("/user/login", {"name": name, "pwd": pwd});

  Map<String, String> buildHeaders({Map<String, String>? headers}) {
    headers ??= {};
    var now = DateTime.now().millisecondsSinceEpoch.toString();
    var R = Random().nextInt(9) + 1; // 1-9
    now = R.toString() + now;
    headers["ks"] = now;
    var xxs = md5.convert(utf8.encode("xxs${now}ks")).toString();
    xxs = xxs.substring(R, R + 8);
    headers["xxs"] = xxs;
    // logging.d("ks: $now -> $xxs");
    return headers;
  }
}

// ignore: non_constant_identifier_names
HttpTool Http = HttpTool();
