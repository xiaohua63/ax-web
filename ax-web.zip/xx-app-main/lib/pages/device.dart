import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:xx_study/components/round_app_bar.dart';
import 'package:xx_study/tools/logger.dart';

import '../components/alert_dialog.dart';
import '../components/base_state.dart';
import '../components/expandable_search_bar.dart';
import '../components/loading_dialog.dart';
import '../tools/http.dart';
import '../tools/ui_utils.dart';
import '../tools/utils.dart';
import '../tools/ws.dart';
import 'accounts.dart';

class DevicePage extends StatefulWidget {
  const DevicePage({super.key});

  @override
  State createState() => DeviceState();
}

void startTask(State state, String deviceId) async {
  var resp = await Http.getJson("${HttpTool.AdminUrl}/dc/start_task",
      queries: {"device_id": deviceId, "task_id": "学习"});
  if (state.mounted) {
    if (resp['code'] == 0) {
      showSnackBar(state.context, "发送成功");
    } else {
      showSnackBar(state.context, "发送失败：${resp['message']}");
    }
  }
}

void stopAllTask(State state, String deviceId, reload) {
  var ctx = state.context;
  showAlert(
    state.context,
    title: deviceId.isEmpty ? "确认停止所有设备任务?" : "确认停止所有任务？",
    content: deviceId.isEmpty ? "*在登录中的设备不会被终止" : "设备：$deviceId",
    onConfirm: () {
      Future.sync(() async {
        var resp = await Http.getJson("${HttpTool.AdminUrl}/dc/stop_all_task",
            queries: {"device_id": deviceId});
        if (resp['code'] == 0) {
          if (state.mounted) {
            showSnackBar(ctx, "操作成功");
            Future.delayed(
              const Duration(milliseconds: 500),
              reload,
            );
          }
        } else {
          if (state.mounted) showSnackBar(ctx, "操作失败：${resp['message']}");
        }
      });
      return true;
    },
  );
}

class DeviceState extends BaseState<DevicePage> with TickerProviderStateMixin {
  String searchDevice = "";

  var searchCtrl = TextEditingController();

  var deviceStatuses = [
    "上号器",
    "全部",
    "发码器",
    "在线",
    "离线",
    "学习完成",
    "学习中",
    "登录中",
    "异常状态"
  ];
  var selDeviceStatus = "上号器";

  @override
  Future<void> onLoad() async {
    var listTask = Http.getJson("${HttpTool.AdminUrl}/admin/devices");
    var resp = await listTask;
    if (resp['code'] == 0) {
      if (resp['data'].isEmpty) {
        notifyError("当前无在线设备");
      } else {
        notifySuccess(resp['data']);
        if (mounted) {
          showSnackBar(context, "刷新成功");
        }
      }
    } else {
      notifyError(resp['message']);
    }
  }

  var showMore = false;
  var onlyOnline = false;

  @override
  Widget buildScaffold(Widget child) {
    if (!fabVisibility) {
      showMore = false;
    }
    return Scaffold(
      floatingActionButton: fabAnimateWrap(
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            SizedBox.square(
              dimension: 40,
              child: InkWell(
                onLongPress: () {
                  setState(() {
                    onlyOnline = !onlyOnline;
                  });
                },
                child: FloatingActionButton.small(
                  shape: const CircleBorder(),
                  onPressed: () => reload(showLoading: false),
                  child: const Icon(Icons.refresh),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 40,
              child: ExpandableSearchBar(
                iconSize: 40,
                textSize: 13,
                backgroundColor: Theme.of(context).colorScheme.background,
                animationDuration: const Duration(milliseconds: 300),
                hintText: "设备搜索(ID)",
                onChanged: (s) => searchDevice = s.trim(),
                onSubmitted: (s) => setState(() {
                  searchDevice = s.trim();
                }),
                editTextController: searchCtrl,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedContainer(
                  width:
                      showMore ? (((PlatformExt.isMobile) ? 44 : 39) * 4) : 0,
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.ease,
                  decoration: const BoxDecoration(),
                  clipBehavior: Clip.none,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        FloatingActionButton.small(
                          shape: const CircleBorder(),
                          onPressed: () {
                            showAlert(
                              context,
                              title: "启动所有学习?",
                              onConfirm: () {
                                startTask(this, "");
                                Future.delayed(
                                  const Duration(milliseconds: 500),
                                  () => reload(showLoading: false),
                                );
                                return true;
                              },
                            );
                          },
                          tooltip: "一键启动",
                          child: const Icon(
                            Icons.play_circle,
                            color: Colors.green,
                          ),
                        ),
                        const SizedBox(width: 10),
                        FloatingActionButton.small(
                          shape: const CircleBorder(),
                          onPressed: () => stopAllTask(
                            this,
                            "",
                            () => reload(showLoading: false),
                          ),
                          tooltip: "一键停止",
                          child: const Icon(
                            Icons.stop_circle,
                            color: Colors.red,
                          ),
                        ),
                        const SizedBox(width: 10),
                        FloatingActionButton.small(
                          shape: const CircleBorder(),
                          onPressed: () => showAlert(
                            context,
                            title: "更新所有设备App?",
                            onConfirm: () async {
                              var resp = await Http.getJson(
                                  "${HttpTool.AdminUrl}/dc/upgrade_app",
                                  queries: {"device_id": ""});
                              print(resp);
                              if (resp["code"] == 0) {
                                if (mounted) {
                                  showSnackBar(context, "指令发送成功");
                                }
                                Future.delayed(
                                  const Duration(milliseconds: 500),
                                  () => reload(showLoading: false),
                                );
                              } else {
                                if (mounted) {
                                  showSnackBar(
                                      context, "发送失败：${resp["message"]}");
                                }
                              }
                              return true;
                            },
                          ),
                          tooltip: "一键更新App",
                          child: const Icon(
                            Icons.update_rounded,
                            color: Colors.blue,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox.square(
                  dimension: 40,
                  child: FloatingActionButton.small(
                    shape: const CircleBorder(),
                    child: Icon(showMore ? Icons.close : Icons.more_horiz),
                    onPressed: () => setState(() {
                      showMore = !showMore;
                      if (!showMore) {
                        // controller?.reverse();
                      } else {
                        // controller?.forward();
                      }
                    }),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: child,
    );
  }

  @override
  Widget buildSuccessView(data) {
    var devices = [];
    searchDevice = searchDevice.toLowerCase();
    if (searchDevice.isNotEmpty) {
      for (var item in data) {
        if (searchDevice.length == 1) {
          if (item['tag'].toLowerCase() == searchDevice) {
            devices.add(item);
          }
        } else {
          if (item["device_id"].toLowerCase().contains(searchDevice) ||
              item['tag'].toLowerCase().contains(searchDevice)) {
            devices.add(item);
          }
        }
      }
    } else {
      devices.addAll(data);
    }
    List<dynamic> all = List.from(devices);
    devices.clear();
    for (var item in all) {
      if (item["app_version"] == "") {
        // error
        continue;
      }
      if (!onlyOnline || item["online"]) {
        devices.add(item);
      }
    }
    devices = filterDeviceStatus(devices, selDeviceStatus);

    List<dynamic> senders = [];
    for (var device in data) {
      if (device["device_id"].startsWith("S-")) senders.add(device);
    }

    var W = MediaQuery.of(context).size.width;

    var senderCnt = senders.length;
    var onSenderCnt = senders.fold(0, (p, e) => p + (e["online"] ? 1 : 0));

    var onDeviceCnt = data.fold(0, (p, e) => p + (e["online"] ? 1 : 0));
    var noAcsCnt = data.fold(
        0, (p, e) => p + (!senders.contains(e) && e["acs_count"] == 0 ? 1 : 0));

    var infoText = "设备：$onDeviceCnt/${data.length}  "
        "上号器：${onDeviceCnt - onSenderCnt}/${data.length - senderCnt}  "
        "发码器：$onSenderCnt/$senderCnt  无账号: $noAcsCnt";

    var dtStyle = const TextStyle(fontSize: 13);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.max,
      children: [
        Padding(
            padding: const EdgeInsets.fromLTRB(8, 2, 8, 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(child: Text(infoText)),
                const SizedBox(width: 10),
                SizedBox(
                  height: 35,
                  child: DropdownButton(
                    focusColor: Colors.transparent,
                    underline: const SizedBox(),
                    value: selDeviceStatus,
                    items: deviceStatuses
                        .map((e) => DropdownMenuItem(
                            value: e,
                            child: Text(
                                "$e ${filterDeviceStatus(data, e).length}",
                                style: dtStyle)))
                        .toList(),
                    onChanged: (e) {
                      setState(() {
                        selDeviceStatus = e!;
                      });
                    },
                  ),
                ),
              ],
            )),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(5.0),
            controller: scrollCtrl,
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: W ~/ 280,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              mainAxisExtent: 190,
            ),
            itemCount: devices.length,
            itemBuilder: (ctx, i) {
              var deviceInfo = devices[i];
              return DeviceItem(i + 1, deviceInfo["device_id"], deviceInfo,
                  () => reload(showLoading: false));
            },
          ),
        ),
      ],
    );
  }

  @override
  bool get wantKeepAlive => true;

  List filterDeviceStatus(List<dynamic> devices, String status) {
    List ret = [];
    for (var d in devices) {
      if (status == "上号器") {
        if (!d["device_id"].toString().startsWith("S-")) {
          ret.add(d);
        }
      } else if (status == "全部") {
        ret.add(d);
      } else if (status == "发码器") {
        if (d["device_id"].toString().startsWith("S-")) {
          ret.add(d);
        }
      } else if (status == "在线") {
        if (d["online"]) {
          ret.add(d);
        }
      } else if (status == "离线") {
        if (!d["online"]) {
          ret.add(d);
        }
      } else if (status == "学习完成") {
        if (d["status"].toString().contains("学习完成")) {
          ret.add(d);
        }
      } else if (status == "学习中") {
        if (d["status"].toString().contains("学习中")) {
          ret.add(d);
        }
      } else if (status == "登录中") {
        if (d["status"].toString().contains("登录")) {
          ret.add(d);
        }
      } else if (status == "异常状态") {
        var s = d["status"].toString();
        if (s.contains("[失败]") ||
            s.contains("超时") ||
            s.contains("阻塞") ||
            s.contains("下线")) {
          ret.add(d);
        }
      }
    }
    return ret;
  }
}

class LogTextSpan extends TextSpan {
  final String? tag;
  final int searchIndex;
  final dataKey = GlobalKey();

  LogTextSpan({
    this.tag,
    this.searchIndex = -1,
    super.text,
    super.children,
    super.style,
    super.recognizer,
    MouseCursor? mouseCursor,
    super.onEnter,
    super.onExit,
    super.semanticsLabel,
    super.locale,
    super.spellOut,
  });

  MapEntry<List<LogTextSpan>, int> searchSplit(String searchText, int index) {
    String text = this.text ?? "";
    String lowText = text.toLowerCase();
    List<String> ss = lowText.split(searchText);
    List<LogTextSpan> ret = [];
    if (ss.length > 1) {
      var p = 0;
      for (var i = 0; i < ss.length; i++) {
        ret.add(fromText(text.substring(p, p + ss[i].length)));
        p += ss[i].length;
        if (p < text.length) {
          ret.add(LogTextSpan(
            text: text.substring(p, p + searchText.length),
            tag: tag,
            searchIndex: index++,
            style: style?.copyWith(backgroundColor: Colors.green),
          ));
          p += searchText.length;
        }
      }
    } else {
      ret.add(this);
    }
    return MapEntry(ret, index);
  }

  LogTextSpan fromText(String text) {
    return LogTextSpan(
      tag: tag,
      text: text,
      style: style,
    );
  }
}

class DeviceItem extends StatefulWidget {
  final int index;
  final String deviceId;
  final dynamic deviceInfo;
  final dynamic reload;

  const DeviceItem(this.index, this.deviceId, this.deviceInfo, this.reload,
      {super.key});

  @override
  State createState() => _DeviceItemState();
}

class _DeviceItemState extends State<DeviceItem> {
  String get deviceId => widget.deviceId;

  dynamic get deviceInfo => widget.deviceInfo;

  String get deviceTag => deviceInfo["tag"];

  var showMoreBtn = false;
  var btnLocked = false;

  @override
  Widget build(BuildContext context) {
    var ip = deviceInfo['ip'];
    var model = deviceInfo['model'];
    var version = int.parse(deviceInfo['app_version']);
    var latestVersion =
        int.parse(deviceInfo['app_latest_ver'] ?? version.toString());
    var loginCount = deviceInfo["acs_login_count"];
    var acsCount = deviceInfo["acs_count"];
    var aniDur = const Duration(milliseconds: 300);
    var studyCnt = deviceInfo["study_cnt"];
    var deviceIsSender = deviceId.startsWith("S-");
    bool online = deviceInfo["online"];
    String status = online ? deviceInfo['status'] ?? "" : "未在线";

    List<dynamic> webStatus = deviceInfo["web_status"];

    Color statusColor = Colors.blueAccent;
    if (!online || status.contains("失败")) {
      statusColor = Colors.redAccent;
    } else if (status.contains("完成") ||
        status.contains("成功") ||
        status.contains("空闲")) {
      statusColor = Colors.green;
    }
    bool anyRunning = webStatus.any((e) => e["running"] == "true");
    return Card(
      color: online
          ? (deviceIsSender ? Colors.lime.shade50 : null)
          : Colors.red.shade100,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
        child: Stack(
          children: [
            if (online && webStatus.isNotEmpty)
              Align(
                alignment: Alignment.topRight,
                child: SizedBox.square(
                  dimension: 30,
                  child: IconButton(
                    padding: EdgeInsets.zero,
                    onPressed: () {
                      showDialogList(
                        context,
                        "${deviceId.substring(0, 6)} Web 状态",
                        webStatus.map((e) {
                          bool running = e["running"] == "true";
                          return Text(
                            "${e['id']}"
                            "  ${running ? "运行中" : "空闲中"} ${e["runningTask"]} "
                            "${e["account"]}",
                            style:
                                TextStyle(color: running ? Colors.green : null),
                          );
                        }).toList(),
                      );
                    },
                    tooltip: "支持WebStudy",
                    icon: Icon(
                      Icons.webhook,
                      color: anyRunning ? Colors.green : null,
                      size: 15,
                    ),
                  ),
                ),
              ),
            if (!online)
              Align(
                alignment: Alignment.topRight,
                child: SizedBox.square(
                  dimension: 30,
                  child: IconButton(
                    padding: EdgeInsets.zero,
                    onPressed: () {
                      showAlert(context, title: "移除设备？", onConfirm: () {
                        Future.sync(() async {
                          var resp = await Http.getJson(
                              "${HttpTool.AdminUrl}/admin/devices/remove",
                              queries: {"device_id": deviceId});
                          if (mounted) {
                            if (resp["code"] == 0) {
                              showSnackBar(context, "移除成功");
                              widget.reload();
                            } else {
                              showSnackBar(context, "移除失败：${resp["message"]}");
                            }
                          }
                        });
                        return true;
                      });
                    },
                    tooltip: "移除设备",
                    icon: const Icon(
                      Icons.close,
                      size: 15,
                    ),
                  ),
                ),
              ),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "设备：${deviceId.substring(0, 6)}${deviceTag.isEmpty ? "" : " ($deviceTag)"}",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: deviceIsSender ? Colors.blue : null,
                  ),
                ),
                AutoSizeText(
                  "机型：$model",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  minFontSize: 12,
                ),
                Tooltip(
                  message: version >= latestVersion ? "" : "可更新：$latestVersion",
                  waitDuration: const Duration(milliseconds: 600),
                  child: Text(
                    "版本：$version",
                    style: TextStyle(
                      color: (deviceId.startsWith("S-") ||
                              version == latestVersion)
                          ? null
                          : (version > latestVersion
                              ? Colors.green
                              : Colors.red),
                    ),
                  ),
                ),
                Text("地址：$ip"),
                Tooltip(
                  waitDuration: const Duration(milliseconds: 500),
                  message: "已学习/已登录/账号数",
                  child: Text(
                    loginCount == acsCount
                        ? "账号：$studyCnt/$acsCount"
                        : "账号：$studyCnt/$loginCount/$acsCount",
                    style: TextStyle(
                      color: (studyCnt > 0 && studyCnt == loginCount)
                          ? Colors.green
                          : (studyCnt > loginCount ? Colors.red : null),
                    ),
                  ),
                ),
                Tooltip(
                  message: status,
                  waitDuration: const Duration(milliseconds: 500),
                  child: AutoSizeText(
                    status,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    minFontSize: 12,
                    style: TextStyle(
                      color: statusColor,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Align(
                  alignment: Alignment.centerRight,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    reverse: true,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.play_circle,
                            color: Colors.green,
                          ),
                          tooltip: btnLocked ? null : "启动学习",
                          onPressed: btnLocked
                              ? null
                              : () {
                                  startTask(this, deviceId);
                                  Future.delayed(const Duration(seconds: 1),
                                      widget.reload);
                                },
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.list_alt,
                            color: Colors.blueAccent,
                          ),
                          tooltip: btnLocked ? null : "账号列表",
                          onPressed: btnLocked ? null : getDeviceAccountList,
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.bug_report_outlined,
                            color: Colors.blueAccent,
                          ),
                          tooltip: btnLocked ? null : "运行日志",
                          onPressed: btnLocked ? null : getLogs,
                        ),
                        AnimatedContainer(
                          width: showMoreBtn ? 0 : 40,
                          duration: aniDur,
                          curve: Curves.ease,
                          onEnd: () => setState(() {
                            btnLocked = false;
                          }),
                          decoration: const BoxDecoration(),
                          clipBehavior: Clip.hardEdge,
                          child: IconButton(
                            icon: const Icon(Icons.more_horiz),
                            onPressed: btnLocked
                                ? null
                                : () => setState(
                                      () {
                                        btnLocked = true;
                                        showMoreBtn = true;
                                      },
                                    ),
                          ),
                        ),
                        AnimatedContainer(
                          width: showMoreBtn
                              ? (((PlatformExt.isMobile) ? 48 : 40) * 5)
                              : 0,
                          curve: Curves.ease,
                          onEnd: () => setState(() {
                            btnLocked = false;
                          }),
                          decoration: const BoxDecoration(),
                          clipBehavior: Clip.antiAlias,
                          duration: aniDur,
                          // wrap with SingleChildScrollView fix overflowed
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(
                                    Icons.account_box_outlined,
                                    color: Colors.blue,
                                  ),
                                  tooltip: btnLocked ? null : "登录账号管理",
                                  onPressed: btnLocked ? null : managerLoginAcs,
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.offline_bolt,
                                    color: Colors.red,
                                  ),
                                  tooltip: btnLocked ? null : "下线",
                                  onPressed: btnLocked ? null : forceOffline,
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.stop_circle,
                                    color: Colors.red,
                                  ),
                                  tooltip: btnLocked ? null : "停止所有任务",
                                  onPressed: btnLocked
                                      ? null
                                      : () => stopAllTask(
                                          this, deviceId, widget.reload),
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.update_rounded,
                                    color: Colors.blueAccent,
                                  ),
                                  tooltip: btnLocked ? null : "更新App",
                                  onPressed: btnLocked ? null : upgradeApp,
                                ),
                                IconButton(
                                  icon: const Icon(Icons.close),
                                  onPressed: btnLocked
                                      ? null
                                      : () => setState(
                                            () {
                                              btnLocked = true;
                                              showMoreBtn = false;
                                            },
                                          ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showLoginAccounts(deviceId) async {
    var resp = await Http.getJson("${HttpTool.AdminUrl}/dc/login_accounts",
        queries: {"device": deviceId});
    if (!mounted) return;
    if (resp['code'] != 0) {
      showSnackBar(context, "获取失败");
      return;
    }
    List l = resp["data"];
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("已登录账号"),
        content: Text(l.join("\n")),
        scrollable: true,
        actions: [
          TextButton(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: l.join("\n")));
                if (mounted) {
                  showSnackBar(ctx, "已复制");
                }
              },
              child: const Text("复制")),
        ],
      ),
    );
  }

  Future<void> getLogs() async {
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/admin/device/log",
        queries: {"device_id": deviceId});
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        showLogs(deviceId, resp['data']);
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  void appendToSpanList(List<LogTextSpan> spanList, String logText) {
    var lastColor =
        spanList.isEmpty ? null : spanList[spanList.length - 1].style?.color;
    var lastTag = spanList.isEmpty ? null : spanList[spanList.length - 1].tag;
    Color? newColor = lastColor;
    if (logText.contains("[ERRO]") || logText.contains("[WARN]")) {
      newColor = Colors.red;
    } else if (logText.contains("[INFO]")) {
      newColor = Colors.black87;
    } else if (logText.contains("[DEBU]")) {
      newColor = Colors.black54;
    } else if (logText.contains("[VERB]")) {
      newColor = Colors.black45;
    }
    String? tag;
    if (logText.contains("[Auto]") || logText.contains("[Login]")) {
      tag = "App";
    } else if (logText.contains("[Web")) {
      tag = "Web";
    }
    if (tag == lastTag && newColor == lastColor && spanList.isNotEmpty) {
      var span = spanList[spanList.length - 1];
      spanList.removeLast();
      logText = "${span.text ?? ""}$logText";
      spanList.add(LogTextSpan(tag: tag, text: logText, style: span.style));
    } else {
      var span = LogTextSpan(
        tag: tag,
        text: logText,
        style: TextStyle(
          color: newColor,
          fontFamily: "FiraMono",
          fontSize: 12.5,
        ),
      );
      spanList.add(span);
    }
  }

  void spanLogText(List<LogTextSpan> spanList, String logs) {
    for (var logText in logs.split('\n')) {
      appendToSpanList(spanList, "\n$logText");
    }
  }

  final _levels = {"[DEBU]": 1, "[INFO]": 2, "[WARN]": 3, "[ERRO]": 4};

  int logTextToLevel(String s) {
    for (var kv in _levels.entries) {
      if (s.contains(kv.key)) {
        return kv.value;
      }
    }
    return 0;
  }

  var logTypeMap = {
    "ALL": null,
    "APP": "[Auto]",
    "WEB": "[Web",
    "WEB0": "[Web0]",
    "WEB1": "[Web1]",
    "WEB2": "[Web2]",
    "WEB3": "[Web3]",
    "WEB4": "[Web4]",
    "WEB5": "[Web5]",
    "WEB6": "[Web6]",
    "WEB7": "[Web7]",
    "WEB8": "[Web8]",
    "WEB9": "[Web9]",
  };

  List<LogTextSpan> filterLogs(List<LogTextSpan> spanList, int level,
      String type, String searchLog, setSearchCount, searchCursor) {
    searchLog = searchLog.toLowerCase();
    if (level <= 0 && type == "ALL" && searchLog.isEmpty) {
      return spanList.toList();
    }
    int searchCount = 0;
    List<LogTextSpan> ret = [];
    var typeText = logTypeMap[type];
    for (var s in spanList) {
      if (logTextToLevel(s.text ?? "") >= level &&
          (typeText == null ||
              (s.text!.length > 18 &&
                  s.text!.substring(18).startsWith(typeText)))) {
        if (searchLog.isEmpty) {
          ret.add(s);
        } else {
          MapEntry a = s.searchSplit(searchLog, searchCount);
          List<LogTextSpan> splitList = a.key;
          searchCount = a.value;
          ret.addAll(splitList);
        }
      }
    }
    setSearchCount(searchCount);
    return ret;
  }

  void showLogs(String device, String logs) async {
    BuildContext? dialogCtx;
    bool newLog = false;
    var sct = ScrollController();
    var fabVis = true;
    var spanList = <LogTextSpan>[];

    var logLevels = ["无", "DEBUG", "INFO", "WARNING", "ERROR"];
    var logTypes = logTypeMap.keys.toList();

    var level = 0;
    String logType = logTypes[0];
    List<LogTextSpan> logList = [];
    String searchLog = "";
    int searchCount = 0;
    int searchCursorIndex = 0;
    void updateLogs(bool scrollBottom) {
      searchCount = 0;
      logList = filterLogs(spanList, level, logType, searchLog, (c) {
        searchCount = c;
      }, searchCursorIndex);
      if (dialogCtx != null) {
        (dialogCtx as Element).markNeedsBuild();
      }
      if (scrollBottom) {
        SchedulerBinding.instance.addPostFrameCallback((_) {
          sct.jumpTo(sct.position.maxScrollExtent);
        });
      }
    }

    AppSocket.sendListenLog(true, device, (String? s) {
      var jump = false;
      if (sct.position.pixels + 150 >= sct.position.maxScrollExtent) {
        jump = true;
      } else {
        newLog = true;
      }
      if (s == null) {
        newLog = false;
        spanList.clear();
      } else {
        spanLogText(spanList, s);
      }
      updateLogs(jump);
    });
    sct.addListener(() {
      if (sct.position.pixels >= sct.position.maxScrollExtent) {
        newLog = false;
        (dialogCtx as Element).markNeedsBuild();
      }
      bool vis = sct.position.userScrollDirection == ScrollDirection.forward;
      if (vis != fabVis) {
        fabVis = vis;
        (dialogCtx as Element).markNeedsBuild();
      }
    });

    void gotoSearchCursor() {
      // todo
      // if (searchCursorIndex == 0) return;
      // for (var s in logList) {
      //   if (s.searchIndex == searchCursorIndex - 1) {
      //     logging.d("found SearchCursor key $s");
      //     SchedulerBinding.instance.addPostFrameCallback((_) {
      //       var ctx = s.dataKey.currentContext;
      //       if (ctx != null) {
      //         Scrollable.ensureVisible(ctx);
      //       } else {
      //         logging.d("SearchCursor ctx is null");
      //       }
      //     });
      //     return;
      //   }
      // }
      // logging.d("not found SearchCursor key. $searchCursorIndex");
    }

    updateLogs(false);
    showModalBottomSheet(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (ctx) {
        dialogCtx = ctx;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: RoundAppBar(
            title: Text("${device.substring(0, 6)} 日志"),
            leading: const CloseButton(),
            actions: [
              SizedBox(
                width: 50,
                child: PopupMenuButton(
                  child: Center(
                    child: Text(logType),
                  ),
                  itemBuilder: (_) => logTypes
                      .map((e) => PopupMenuItem(
                            value: e,
                            child: Text(e),
                          ))
                      .toList(),
                  onSelected: (i) {
                    logType = i;
                    updateLogs(true);
                  },
                ),
              ),
              const SizedBox(width: 6),
              PopupMenuButton(
                child: SizedBox(
                  width: 100,
                  height: double.infinity,
                  child: Center(
                      child: AutoSizeText(
                    "LEVEL: ${logLevels[level]}",
                    minFontSize: 9,
                    softWrap: false,
                  )),
                ),
                itemBuilder: (_) => logLevels
                    .map((e) => PopupMenuItem(
                          value: e,
                          child: Text(e),
                        ))
                    .toList(),
                onSelected: (i) {
                  level = logLevels.indexOf(i);
                  updateLogs(true);
                },
              ),
              const SizedBox(width: 6),
              IconButton(
                tooltip: "清空日志",
                onPressed: () {
                  showAlert(context, title: "清空设备日志？", onConfirm: () {
                    Future.sync(() async {
                      var resp = await Http.getJson(
                          "${HttpTool.AdminUrl}/admin/device/clear_log",
                          queries: {"device_id": deviceId});
                      if (resp["code"] == 0) {
                        if (mounted) {
                          spanList.clear();
                          (ctx as Element).markNeedsBuild();
                          showSnackBar(ctx, "清除完成");
                        }
                      }
                    });
                    return true;
                  });
                },
                icon: const Icon(Icons.cleaning_services_rounded),
              )
            ],
          ),
          body: Container(
            color: Theme.of(context).colorScheme.background,
            child: Stack(
              children: [
                SizedBox(
                  width: double.maxFinite,
                  child: SingleChildScrollView(
                    controller: sct,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(10, 5, 10, 10),
                      child: SelectableText.rich(
                        TextSpan(children: logList),
                      ),
                    ),
                  ),
                ),
                if (searchLog.isNotEmpty)
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text("$searchCursorIndex/$searchCount"),
                          const SizedBox(width: 10),
                          IconButton(
                            icon: const Icon(Icons.navigate_before),
                            onPressed: searchCursorIndex <= 0
                                ? null
                                : () {
                                    searchCursorIndex--;
                                    gotoSearchCursor();
                                    (dialogCtx as Element).markNeedsBuild();
                                  },
                          ),
                          IconButton(
                            icon: const Icon(Icons.navigate_next),
                            onPressed: searchCursorIndex >= searchCount
                                ? null
                                : () {
                                    setState(() {
                                      searchCursorIndex++;
                                    });
                                    gotoSearchCursor();
                                  },
                          ),
                        ],
                      ),
                    ),
                  ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      fabAnimateWrap2(
                        fabVis,
                        Padding(
                          padding: const EdgeInsets.only(bottom: 20, right: 20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              FloatingActionButton.small(
                                child: const Icon(Icons.vertical_align_top),
                                onPressed: () {
                                  sct.jumpTo(0);
                                },
                              ),
                              const SizedBox(height: 10),
                              FloatingActionButton.small(
                                child: const Icon(Icons.vertical_align_bottom),
                                onPressed: () {
                                  sct.jumpTo(sct.position.maxScrollExtent);
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 20, right: 20),
                        child: SizedBox(
                          height: 40,
                          child: ExpandableSearchBar(
                            iconSize: 40,
                            textSize: 13,
                            backgroundColor:
                                Theme.of(context).colorScheme.background,
                            animationDuration:
                                const Duration(milliseconds: 300),
                            hintText: "日志搜索",
                            onChanged: (s) => searchLog = s.trim(),
                            onSubmitted: (s) {
                              setState(() {
                                searchLog = s.trim();
                              });
                              updateLogs(true);
                              searchCursorIndex = searchCount;
                              gotoSearchCursor();
                            },
                            editTextController: TextEditingController(
                              text: searchLog,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: newLog,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 20),
                      child: ElevatedButton(
                        onPressed: () {
                          sct.jumpTo(sct.position.maxScrollExtent);
                        },
                        child: const Text("↓新内容↓"),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    ).then((value) {
      AppSocket.sendListenLog(false, device, null);
    });
    Future.delayed(const Duration(milliseconds: 250), () {
      spanLogText(spanList, logs);
      updateLogs(true);
    });
  }

  void managerLoginAcs() async {
    var resp = await Http.getJson(
        "${HttpTool.AdminUrl}/admin/device/login_accounts",
        queries: {"device_id": deviceId});
    if (resp["code"] == 0) {
      List loginAcs = resp["data"];
      if (mounted) {
        showDialogList(context, "已登录账号(${loginAcs.length})",
            loginAcs.map((e) => Text(e)).toList(),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    addLoginAcs();
                  },
                  child: const Text("添加"))
            ]);
      }
    } else {
      if (mounted) showSnackBar(context, "获取失败：${resp["message"]}");
    }
  }

  void postAddLoginAcs(List<String> acs) async {
    logging.d("postAddLoginAcs $acs");
    var resp = await Http.postJson(
        "${HttpTool.AdminUrl}/admin/devices/add_login_acs", acs,
        queries: {"device_id": deviceId});
    if (resp["code"] == 0) {
      if (mounted) showSnackBar(context, "添加成功");
    } else {
      if (mounted) showSnackBar(context, "添加失败：${resp["message"]}");
    }
  }

  void addLoginAcs() {
    var ctrl = TextEditingController();
    void process() {
      String a = ctrl.text.toString();
      if (a.isEmpty) return;
      if (a.startsWith("[")) {
        a = a.replaceAll("'", '"');
        List acs = jsonDecode(a);
        if (acs.isNotEmpty) {
          Navigator.pop(context);
          postAddLoginAcs(List.from(acs));
        }
      } else {
        Navigator.pop(context);
        postAddLoginAcs([a]);
      }
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("添加登录账号"),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          onSubmitted: (s) => process(),
        ),
        actions: [TextButton(onPressed: process, child: const Text("添加"))],
      ),
    );
  }

  void forceOffline() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("确认下线？"),
        content: Text("设备：$deviceId"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text("取消")),
          TextButton(
              onPressed: () async {
                var resp = await Http.getJson("${HttpTool.AdminUrl}/dc/offline",
                    queries: {"device_id": deviceId});
                if (resp['code'] == 0) {
                  if (mounted) {
                    Navigator.pop(ctx);
                    showSnackBar(ctx, "操作成功");
                    Future.delayed(
                        const Duration(milliseconds: 500), widget.reload);
                  }
                } else {
                  if (mounted) showSnackBar(ctx, "操作失败：${resp['message']}");
                }
              },
              child: const Text("确认"))
        ],
      ),
    );
  }

  void upgradeApp() {
    if (AppSocket.connected) {
      AppSocket.upgradeApp(deviceId);
      showSnackBar(context, "指令发送成功");
      Future.delayed(const Duration(seconds: 1), widget.reload());
    } else {
      showSnackBar(context, "当前Socket未建立连接，请刷新页面再试");
    }
  }

  Future<void> getDeviceAccountList() async {
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/admin/device/accounts",
        queries: {"device_id": deviceId});
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        showAccountList(deviceId, resp['data']);
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  void showAccountList(String deviceId, accounts) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: double.infinity),
      builder: (ctx) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: RoundAppBar(
            title: Text("${deviceId.substring(0, 6)} 账号列表"),
            leading: const CloseButton(),
          ),
          body: AccountsPage.withData(accounts, true, 0),
        );
      },
    );
  }
}
