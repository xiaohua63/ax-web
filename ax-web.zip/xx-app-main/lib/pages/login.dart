import 'package:flutter/material.dart';

import '../components/input_dialog.dart';
import '../tools/config.dart';
import '../tools/http.dart';
import '../tools/logger.dart';
import '../tools/ui_utils.dart';
import '../tools/utils.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State createState() => LoginState();
}

class LoginState extends State<LoginPage> {
  TextEditingController nameCtrl = TextEditingController();
  TextEditingController pwdCtrl = TextEditingController();

  bool inLogin = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SizedBox(
          width: 300,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: nameCtrl,
                autofocus: true,
                keyboardType: TextInputType.text,
                decoration: const InputDecoration(
                    labelText: "用户名", prefixIcon: Icon(Icons.person)),
              ),
              TextField(
                controller: pwdCtrl,
                keyboardType: TextInputType.visiblePassword,
                obscureText: true,
                textInputAction: TextInputAction.go,
                onSubmitted: (_) => login(),
                decoration: const InputDecoration(
                    labelText: "密码", prefixIcon: Icon(Icons.lock)),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: 300,
                child: inLogin
                    ? const Center(child: CircularProgressIndicator())
                    : ElevatedButton(
                        onPressed: login,
                        child: const Text("登录"),
                      ),
              ),
              const SizedBox(height: 20),
              TextButton(
                onPressed: setNewHostUrl,
                child: const Text(
                  "设置接口地址",
                  style: TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void setNewHostUrl() {
    showInputDialog(context, "设置接口地址", initText: HttpTool.baseUrl)
        .then((value) {
      if (value != null) {
        AppConfig.setHostUrl(value);
        HttpTool.baseUrl = value;
      }
    });
  }

  void login() async {
    if (HttpTool.baseUrl.isEmpty) {
      showSnackBar(context, '请先设置接口地址');
      return;
    }
    String name = nameCtrl.text.trim();
    String pwd = pwdCtrl.text.trim();
    if (name.length < 4) {
      showSnackBar(context, '用户名长度至少为4');
      return;
    }
    if (pwd.isEmpty) {
      showSnackBar(context, '密码不可空');
      return;
    }
    pwd = signPwd(pwd);
    setState(() {
      inLogin = true;
    });
    var resp = await Http.login(name, pwd);
    await Future.delayed(const Duration(milliseconds: 300), null);
    if (resp['code'] == 0) {
      logging.d("token: ${resp['data']}");
      AppConfig.saveToken(resp['data']);
      if (!mounted) return;
      Navigator.of(context).pushReplacementNamed("/manager");
    } else {
      if (!mounted) return;
      showSnackBar(context, resp['message']);
    }
    setState(() {
      inLogin = false;
    });
  }
}
