import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:xx_study/components/loading_dialog.dart';
import 'package:xx_study/components/round_app_bar.dart';
import 'package:xx_study/tools/logger.dart';

import '../tools/http.dart';
import '../tools/ui_utils.dart';
import '../tools/utils.dart';
import 'accounts.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State createState() => AdminState();
}

class AdminState extends State<AdminPage> with AutomaticKeepAliveClientMixin {
  Future<bool> reqGenActCode(String count, String score) async {
    var resp = await Http.getJson("${HttpTool.AdminUrl}/ac/generate",
        queries: {"count": count, "score": score});
    if (resp['code'] == 0) {
      if (mounted) {
        Navigator.pop(context);
        showCodes(resp['data']);
      }
      return true;
    } else {
      if (mounted) {
        showSnackBar(context, "失败：${resp['message']}");
      }
    }
    return false;
  }

  void showCodes(List<dynamic> codes) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => Scaffold(
        backgroundColor: Colors.transparent,
        appBar: RoundAppBar(
          leading: const CloseButton(),
          title: const Text("激活码"),
          actions: [
            TextButton(
                onPressed: () async {
                  await Clipboard.setData(
                      ClipboardData(text: codes.join('\n')));
                  if (mounted) {
                    showSnackBar(context, "已复制");
                  }
                },
                child: const Text("复制")),
          ],
        ),
        body: Container(
          color: Theme.of(context).colorScheme.background,
          child: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              itemCount: codes.length,
              itemBuilder: (ctx, i) {
                return ListTile(
                  title: Text(codes[i]),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  void loginLog() async {
    var d = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/admin/login_log");
    logging.d(resp);
    d.dismiss();
    if (resp['code'] == 0) {
      List data = resp["data"];
      if (mounted) {
        showLoginLog(data);
      }
    } else {
      if (mounted) {
        showSnackBar(context, "请求失败：${resp['message']}");
      }
    }
  }

  void showLoginLog(data) {
    var selectPhone = "";

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => Scaffold(
        backgroundColor: Colors.transparent,
        appBar: RoundAppBar(
          title: const Text("登录日志"),
          leading: const CloseButton(),
        ),
        body: SelectionArea(
          child: ListView(
            children: List.from(data
                .map((e) => InkWell(
                      onTap: () {
                        selectPhone = e["name"];
                        (ctx as Element).markNeedsBuild();
                      },
                      child: Container(
                        color: e["name"] == selectPhone
                            ? const Color(0x4F82B1FF)
                            : null,
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("(${e['id']}) 账号：${e["name"]}(${e["account"]})  [${e["user"]}]"),
                              Text(
                                  "设备：${e["device"].toString().substring(0, 6)} \t"
                                  " 验证码：${e["code"]}"),
                              Text(
                                  "时间：${formatDate(DateTime.parse(e["create_time"]), format: "MM/dd HH:mm:ss")}  "
                                      "->  ${e["result_time"]==null? "null" : formatDate(DateTime.parse(e["result_time"]), format: "HH:mm:ss")}"),
                              if (e["success"] != null)
                                Text(
                                  e["success"] ? "成功" : "失败：${e["reason"]}",
                                  style: TextStyle(
                                    color: e["success"]
                                        ? Colors.green
                                        : Colors.red,
                                  ),
                                )
                              else
                                const Text(
                                  "登录中",
                                  style: TextStyle(color: Colors.blueAccent),
                                )
                            ],
                          ),
                        ),
                      ),
                    ))
                .toList()),
          ),
        ),
      ),
    );
  }

  void genActCode() {
    var ctCtrl = TextEditingController();
    ctCtrl.text = '20';
    var scoreCtrl = TextEditingController();
    scoreCtrl.text = '50';
    var enabled = true;
    void update(ctx, _) {
      enabled = scoreCtrl.text.isNotEmpty && ctCtrl.text.isNotEmpty;
      (ctx as Element).markNeedsBuild();
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("添加激活码"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ctCtrl,
              onChanged: (s) => update(ctx, s),
              decoration: const InputDecoration(labelText: "数量"),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
            TextField(
              controller: scoreCtrl,
              onChanged: (s) => update(ctx, s),
              decoration: const InputDecoration(labelText: "积分"),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text("取消")),
          TextButton(
              onPressed: enabled
                  ? () => reqGenActCode(ctCtrl.text, scoreCtrl.text)
                  : null,
              child: const Text("生成"))
        ],
      ),
    );
  }

  void showSmsPhoneQueue() async {
    var d = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/app/phone_queue");
    d.dismiss();
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("发码队列"),
        content: SelectableText(resp.join("\n")),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("OK"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextButton(onPressed: genActCode, child: const Text("生成激活码")),
        TextButton(onPressed: loginLog, child: const Text("账号登录日志")),
        TextButton(onPressed: showSmsPhoneQueue, child: const Text("发码队列")),
        TextButton(onPressed: getAberrantAcs, child: const Text("异常账号列表")),
        TextButton(onPressed: getAgentAccounts, child: const Text("代理账号查询")),
        TextButton(onPressed: getAberrantLog, child: const Text("异常记录")),
        TextButton(
            onPressed: searchAccountTrustLog, child: const Text("账号信任设备查询")),
      ],
    );
  }

  void getAberrantAcs() async {
    var dialog = showLoadingDialog(context);
    var resp =
        await Http.getJson("${HttpTool.AdminUrl}/admin/get_bad_accounts");
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        showAccountList("异常账号列表", resp['data']);
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  void searchAccountTrustLog() {
    var ctrl = TextEditingController();
    var enabled = false;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("账号信任设备查询"),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(labelText: "手机号"),
          onChanged: (s) {
            enabled = s.trim().isNotEmpty;
            (ctx as Element).markNeedsBuild();
          },
          onSubmitted:
              enabled ? (s) => doSearchAccountTrustLog(ctx, s.trim()) : null,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("取消"),
          ),
          TextButton(
            onPressed: !enabled
                ? null
                : () => doSearchAccountTrustLog(ctx, ctrl.text.trim()),
            child: const Text("查询"),
          ),
        ],
      ),
    );
  }

  void doSearchAccountTrustLog(ctx, String phone) async {
    Navigator.pop(ctx);
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson(
        "${HttpTool.AdminUrl}/admin/trust_device/search",
        queries: {"phone": phone});
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        showCommonList(
          context,
          "$phone 信任设备",
          resp['data']
              .map(
                (e) => ListTile(
                  title: Text("账号：${e['extra_info']} / id:${e["extra_id"]}"),
                  subtitle:
                      Text("时间： ${reformatDate(e["date"])}\n设备：${e['detail']}"),
                ),
              )
              .toList(),
        );
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  void getAberrantLog() async {
    var dialog = showLoadingDialog(context);
    var resp =
        await Http.getJson("${HttpTool.AdminUrl}/admin/account_aberrant/list");
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        var types = {31: "账号异常", 32: "认证提醒", 33: "异常提醒"};
        showCommonList(
          context,
          "异常记录",
          resp['data']
              .map(
                (e) => ListTile(
                  title: Text(
                    "【${types[e['type']] ?? e['type']}】 账号：${e['extra_info']}",
                  ),
                  subtitle:
                      Text("时间：${reformatDate(e["date"])}\n设备：${e['detail']}"),
                ),
              )
              .toList(),
        );
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  void showAccountList(String title, accounts) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      constraints: const BoxConstraints(maxWidth: double.infinity),
      useSafeArea: true,
      builder: (ctx) => Scaffold(
        backgroundColor: Colors.transparent,
        appBar: RoundAppBar(
          title: Text(title),
          leading: const CloseButton(),
        ),
        body: AccountsPage.withData(accounts, true, 0),
      ),
    );
  }

  void getAgentAccounts() async {
    var ctrl = TextEditingController();
    var enabled = false;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("代理账号查询"),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(labelText: "代理名"),
          onChanged: (s) {
            enabled = s.trim().isNotEmpty;
            (ctx as Element).markNeedsBuild();
          },
          onSubmitted: enabled ? (s) => queryAgentAcs(ctx, s.trim()) : null,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("取消"),
          ),
          TextButton(
            onPressed:
                !enabled ? null : () => queryAgentAcs(ctx, ctrl.text.trim()),
            child: const Text("查询"),
          ),
        ],
      ),
    );
  }

  Future<void> queryAgentAcs(ctx, agent) async {
    Navigator.pop(ctx);
    var dialog = showLoadingDialog(context);
    var resp = await Http.getJson("${HttpTool.AdminUrl}/admin/agent_accounts",
        queries: {"agent_name": agent});
    if (mounted) {
      dialog.dismiss();
      if (resp['code'] == 0) {
        showAccountList("代理 $agent 账号列表", resp['data']);
      } else {
        showSnackBar(context, "获取失败：${resp['message']}");
      }
    }
  }

  @override
  bool get wantKeepAlive => true;
}
