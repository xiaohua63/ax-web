import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../components/base_state.dart';
import '../tools/http.dart';
import '../tools/ws.dart';

class HomePage extends StatefulWidget {
  final Function loadUserInfo;

  const HomePage(this.loadUserInfo, {super.key});

  @override
  State createState() => HomeState();
}

class HomeState extends BaseState<HomePage> {
  String appVersion = "";

  @override
  void initState() {
    super.initState();
    Future.sync(() async {
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      appVersion = packageInfo.version;
    });
  }

  @override
  Widget buildSuccessView(data) {
    Map<String, dynamic> homeData = data;
    String s = "";
    if (homeData.containsKey("admin_text")) {
      s = homeData["admin_text"];
    }

    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: SelectableText((homeData.containsKey("home_text")
                    ? homeData["home_text"]
                    : "余额：${homeData['balance']}\n"
                        "账号数量：${homeData['account_total_size']}\n"
                        "过期账号数量：${homeData['account_total_size'] - homeData['account_valid_size']}\n"
                        "公告：${homeData['announce']}\n") +
                "\n$s\n\nVersion: $appVersion"),
          ),
          Center(
            child: TextButton(
              onPressed: reload,
              child: const Text("刷新"),
            ),
          )
        ],
      ),
    );
  }

  @override
  Future<void> onLoad() async {
    dynamic resp;
    try {
      resp = await Http.getJson("/user/home");
    } catch (e) {
      notifyError("网络错误", action: () {
        if (!AppSocket.running) {
          widget.loadUserInfo();
        }
      });
      return;
    }
    if (resp['code'] == 0) {
      notifySuccess(resp['data']);
    } else if (resp['code'] == -9) {
      notifyNoLogin();
    } else {
      notifyError("网络错误: ${resp['message']}");
    }
  }

  @override
  bool get wantKeepAlive => true;
}
