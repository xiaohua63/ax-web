import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:xx_study/tools/http.dart';

import '../pages/login.dart';
import '../pages/manager.dart';
import '../tools/config.dart';
import '../tools/logger.dart';

void main() {
  AxApp app = const AxApp();
  runZonedGuarded(
    () {
      runApp(app);
    },
    (error, stackTrace) {
      logging.d(error);
      logging.d(stackTrace);
      // showSnackBar(app.ctx, "发生错误：$error");
    },
  );
}

class AxApp extends StatelessWidget {
  static bool appEnabled = false;

  const AxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '自营爱学平台',
      theme: ThemeData(
        // colorScheme: const ColorScheme.dark(
        // primary: Colors.white60,
        // onPrimary:Colors.white ,
        // secondary: Colors.lightBlue,
        // ),
        useMaterial3: true,
      ),
      routes: {
        "/": (context) => const LaunchPage(),
        "/login": (context) => const LoginPage(),
        "/manager": (context) => const ManagerPage()
      },
    );
  }
}

class LaunchPage extends StatefulWidget {
  const LaunchPage({super.key});

  @override
  State<LaunchPage> createState() => _LaunchPageState();
}

class _LaunchPageState extends State<LaunchPage> {
  bool visibility = true;

  @override
  void initState() {
    super.initState();
    Future.sync(() async {
      AxApp.appEnabled = false;
      visibility = true;
      if (!kDebugMode && !await checkEnabled()) {
        setState(() {
          visibility = false;
        });
        return;
      }
      AxApp.appEnabled = true;
      if (mounted) {
        if (!await AppConfig.isLogin()) {
          Navigator.of(context).popAndPushNamed("/login");
        } else {
          Navigator.of(context).popAndPushNamed("/manager");
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Visibility(
        visible: visibility,
        child: const CircularProgressIndicator(),
      ),
    );
  }

  Future<bool> checkEnabled() async {
    var u = await AppConfig.hostUrl();
    if (u != null) {
      HttpTool.baseUrl = u;
    }
    return true;
  }
}
