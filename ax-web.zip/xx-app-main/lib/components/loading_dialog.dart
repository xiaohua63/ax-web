import 'package:flutter/material.dart';

abstract class BaseDialog<T> {
  BuildContext? dialogCtx;
  late Future<T?> dialogFuture;

  void dismiss() {
    if (dialogCtx != null) {
      Navigator.pop(dialogCtx!);
    } else {
      Future.delayed(const Duration(milliseconds: 100))
          .then((value) => dismiss());
    }
  }

  void then(void Function(T? value) onValue) {
    dialogFuture.then((value) => onValue(value));
  }

  void show(context);
}

class LoadingDialog extends BaseDialog {
  String title;

  LoadingDialog({this.title = ""});

  @override
  void show(context) {
    dialogFuture = showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        dialogCtx = ctx;
        return AlertDialog(
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title),
              const SizedBox(
                width: 80,
                height: 40,
                child: Center(
                  child: SizedBox.square(
                    dimension: 30,
                    child: CircularProgressIndicator(),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

LoadingDialog showLoadingDialog(context, {String title = ""}) {
  var dialog = LoadingDialog();
  dialog.show(context);
  return dialog;
}
