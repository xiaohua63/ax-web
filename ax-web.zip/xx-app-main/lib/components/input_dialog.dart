import 'package:flutter/material.dart';
import 'package:xx_study/components/loading_dialog.dart';

class InputDialog extends BaseDialog<String> {
  String title;
  String initText;
  String hintText;
  String labelText;
  String message;

  InputDialog(
      this.title, this.initText, this.hintText, this.labelText, this.message);

  @override
  void show(context) {
    var ctrl = TextEditingController(text: initText);
    dialogFuture = showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        dialogCtx = ctx;
        return AlertDialog(
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (message.isNotEmpty) Text(message),
              const SizedBox(height: 8),
              TextField(
                autofocus: true,
                onSubmitted: (s) {
                  Navigator.pop(ctx, s);
                },
                controller: ctrl,
                decoration: InputDecoration(
                  hintText: hintText,
                  labelText: labelText,
                  border: const OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
              },
              child: const Text("取消"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(ctx, ctrl.text);
              },
              child: const Text("确定"),
            )
          ],
        );
      },
    );
  }
}

InputDialog showInputDialog(context, String title,
    {String initText = "",
    String hintText = "",
    String labelText = "",
    String message = ""}) {
  var dialog = InputDialog(title, initText, hintText, labelText, message);
  dialog.show(context);
  return dialog;
}

Future<T?> showMessageDialog<T>(context, String title, String message,
    {List<Widget>? actions, String negText = "关闭"}) {
  var buttons = actions ?? [];
  return showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        ...buttons,
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: Text(negText),
        ),
      ],
    ),
  );
}
